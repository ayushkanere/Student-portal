const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

const StudentSchema = new mongoose.Schema(
  {
    fullName: {
      type: String,
      trim: true,
      default: ''
    },
    studentId: {
      type: String,
      trim: true,
      uppercase: true,
      unique: true,
      sparse: true // Allows null/missing values without duplicate key errors
    },
    collegeEmail: {
      type: String,
      required: [true, 'College email is required'],
      unique: true,
      trim: true,
      lowercase: true,
      match: [emailRegex, 'Please provide a valid college email format (e.g. student@college.edu)']
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: [6, 'Password must be at least 6 characters long'],
      select: false // Never return password hash in queries by default
    },
    phoneNumber: {
      type: String,
      trim: true,
      default: ''
    },
    dateOfBirth: {
      type: String,
      trim: true,
      default: ''
    },
    gender: {
      type: String,
      enum: ['Male', 'Female', 'Other', ''],
      default: ''
    },
    courseDegree: {
      type: String,
      trim: true,
      default: ''
    },
    department: {
      type: String,
      trim: true,
      default: ''
    },
    semesterYear: {
      type: String,
      trim: true,
      default: ''
    },
    cgpa: {
      type: Number,
      min: [0, 'CGPA cannot be negative'],
      max: [10, 'CGPA cannot exceed 10.0'],
      default: null
    },
    profileStrength: {
      type: Number,
      min: 0,
      max: 100,
      default: 0
    },
    resumeUrl: {
      type: String,
      trim: true,
      default: ''
    }
  },
  {
    timestamps: true
  }
);

// Method to calculate profile strength percentage based on completed fields
StudentSchema.methods.calculateProfileStrength = function () {
  const fieldsToCheck = [
    this.fullName,
    this.studentId,
    this.collegeEmail,
    this.phoneNumber,
    this.dateOfBirth,
    this.gender,
    this.courseDegree,
    this.department,
    this.semesterYear,
    this.cgpa,
    this.resumeUrl
  ];

  let filledCount = 0;
  fieldsToCheck.forEach((val) => {
    if (val !== undefined && val !== null && String(val).trim() !== '') {
      filledCount++;
    }
  });

  return Math.round((filledCount / fieldsToCheck.length) * 100);
};

// Pre-save hook: auto-hash password if modified and recalculate profile strength
StudentSchema.pre('save', async function (next) {
  // Hash password if modified
  if (this.isModified('password')) {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
  }

  // Recalculate profile strength
  this.profileStrength = this.calculateProfileStrength();

  next();
});

// Instance method to compare password during login
StudentSchema.methods.comparePassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('Student', StudentSchema);
