const express = require('express');
const router = express.Router();
const { signup, login } = require('../controllers/authController');

// POST /api/auth/signup - Register new student
router.post('/signup', signup);

// POST /api/auth/login - Login with email or studentId + password
router.post('/login', login);

module.exports = router;
