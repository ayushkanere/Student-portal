const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const upload = require('../middleware/uploadMiddleware');
const {
  getMyProfile,
  updateMyProfile,
  uploadResume
} = require('../controllers/profileController');

// All profile routes are protected by JWT authentication middleware
router.use(protect);

// GET /api/profile/me - Get current student profile
router.get('/me', getMyProfile);

// PUT /api/profile/me - Update student profile fields
router.put('/me', updateMyProfile);

// POST /api/profile/upload-resume - Upload resume file (PDF/DOCX, max 5MB)
router.post('/upload-resume', (req, res, next) => {
  upload.single('resume')(req, res, (err) => {
    if (err) {
      return res.status(400).json({
        success: false,
        message: err.message || 'File upload failed.'
      });
    }
    next();
  });
}, uploadResume);

module.exports = router;
