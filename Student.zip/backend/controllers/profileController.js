const path = require('path');
const Student = require('../models/Student');

/**
 * @desc    Get current logged-in student profile
 * @route   GET /api/profile/me
 * @access  Private (JWT Protected)
 */
const getMyProfile = async (req, res) => {
  try {
    const student = await Student.findById(req.student._id).select('-password');
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student profile not found.'
      });
    }

    return res.status(200).json({
      success: true,
      student
    });
  } catch (error) {
    console.error('[Get Profile Error]:', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Error retrieving profile data.'
    });
  }
};

/**
 * @desc    Update current logged-in student profile
 * @route   PUT /api/profile/me
 * @access  Private (JWT Protected)
 */
const updateMyProfile = async (req, res) => {
  try {
    const student = await Student.findById(req.student._id);
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student profile not found.'
      });
    }

    const {
      fullName,
      studentId,
      phoneNumber,
      dateOfBirth,
      gender,
      courseDegree,
      department,
      semesterYear,
      cgpa
    } = req.body;

    // Check duplicate studentId if changing studentId
    if (studentId !== undefined && studentId.trim() !== '') {
      const cleanStudentId = studentId.trim().toUpperCase();
      if (student.studentId !== cleanStudentId) {
        const existingStudent = await Student.findOne({
          studentId: cleanStudentId,
          _id: { $ne: student._id }
        });
        if (existingStudent) {
          return res.status(409).json({
            success: false,
            message: `Student ID ${cleanStudentId} is already assigned to another student.`
          });
        }
        student.studentId = cleanStudentId;
      }
    }

    // Apply allowed partial updates
    if (fullName !== undefined) student.fullName = fullName.trim();
    if (phoneNumber !== undefined) student.phoneNumber = phoneNumber.trim();
    if (dateOfBirth !== undefined) student.dateOfBirth = dateOfBirth.trim();
    if (gender !== undefined) student.gender = gender;
    if (courseDegree !== undefined) student.courseDegree = courseDegree.trim();
    if (department !== undefined) student.department = department.trim();
    if (semesterYear !== undefined) student.semesterYear = semesterYear.trim();

    if (cgpa !== undefined) {
      if (cgpa === '' || cgpa === null) {
        student.cgpa = null;
      } else {
        const parsedCgpa = parseFloat(cgpa);
        if (isNaN(parsedCgpa) || parsedCgpa < 0 || parsedCgpa > 10) {
          return res.status(400).json({
            success: false,
            message: 'CGPA must be a valid number between 0.0 and 10.0.'
          });
        }
        student.cgpa = parsedCgpa;
      }
    }

    // Save triggers pre-save hook which recalculates profileStrength
    await student.save();

    const sanitized = student.toObject();
    delete sanitized.password;

    return res.status(200).json({
      success: true,
      message: 'Profile updated successfully.',
      student: sanitized
    });
  } catch (error) {
    console.error('[Update Profile Error]:', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Error updating profile data.'
    });
  }
};

/**
 * @desc    Upload student placement resume (PDF/DOCX, max 5MB)
 * @route   POST /api/profile/upload-resume
 * @access  Private (JWT Protected)
 */
const uploadResume = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No resume file uploaded. Please select a PDF or DOCX document.'
      });
    }

    const student = await Student.findById(req.student._id);
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student record not found.'
      });
    }

    // Public URL path accessible via Express static serving
    const relativeUrl = `/uploads/resumes/${req.file.filename}`;
    student.resumeUrl = relativeUrl;

    await student.save();

    return res.status(200).json({
      success: true,
      message: 'Resume uploaded and verified successfully.',
      resumeUrl: relativeUrl,
      fileName: req.file.originalname,
      fileSize: (req.file.size / 1024).toFixed(1) + ' KB',
      profileStrength: student.profileStrength
    });
  } catch (error) {
    console.error('[Upload Resume Error]:', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Error uploading resume file.'
    });
  }
};

module.exports = {
  getMyProfile,
  updateMyProfile,
  uploadResume
};
