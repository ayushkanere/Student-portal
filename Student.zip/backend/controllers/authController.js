const jwt = require('jsonwebtoken');
const Student = require('../models/Student');

const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

// Helper to generate JWT token (7-day validity)
const generateToken = (student) => {
  return jwt.sign(
    {
      id: student._id,
      collegeEmail: student.collegeEmail,
      studentId: student.studentId || ''
    },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
};

// Helper to sanitize student data for response (remove password)
const sanitizeStudent = (student) => {
  const obj = student.toObject ? student.toObject() : { ...student };
  delete obj.password;
  return obj;
};

/**
 * @desc    Register a new student
 * @route   POST /api/auth/signup
 * @access  Public
 */
const signup = async (req, res) => {
  try {
    const {
      fullName,
      studentId,
      collegeEmail,
      password,
      phoneNumber,
      courseDegree,
      department
    } = req.body;

    // Validate required fields
    if (!collegeEmail || !collegeEmail.trim()) {
      return res.status(400).json({
        success: false,
        message: 'College email address is required.'
      });
    }

    const cleanEmail = collegeEmail.trim().toLowerCase();
    if (!emailRegex.test(cleanEmail)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid college email format (e.g. student@college.edu).'
      });
    }

    if (!password || password.trim().length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.'
      });
    }

    // Check duplicate collegeEmail
    const existingEmail = await Student.findOne({ collegeEmail: cleanEmail });
    if (existingEmail) {
      return res.status(409).json({
        success: false,
        message: 'An account with this college email already exists. Please log in instead.'
      });
    }

    // Check duplicate studentId if provided
    let cleanStudentId = studentId ? studentId.trim().toUpperCase() : undefined;
    if (cleanStudentId) {
      const existingId = await Student.findOne({ studentId: cleanStudentId });
      if (existingId) {
        return res.status(409).json({
          success: false,
          message: `An account with Student ID ${cleanStudentId} already exists.`
        });
      }
    }

    // Create new student
    const student = new Student({
      fullName: fullName ? fullName.trim() : '',
      studentId: cleanStudentId,
      collegeEmail: cleanEmail,
      password: password.trim(),
      phoneNumber: phoneNumber ? phoneNumber.trim() : '',
      courseDegree: courseDegree ? courseDegree.trim() : '',
      department: department ? department.trim() : ''
    });

    await student.save();

    const token = generateToken(student);

    return res.status(201).json({
      success: true,
      message: 'Student registered successfully.',
      token,
      student: sanitizeStudent(student)
    });
  } catch (error) {
    console.error('[Signup Error]:', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Internal server error during registration.'
    });
  }
};

/**
 * @desc    Login student with collegeEmail OR studentId + password
 * @route   POST /api/auth/login
 * @access  Public
 */
const login = async (req, res) => {
  try {
    const { identifier, collegeEmail, studentId, password } = req.body;

    // Support identifier as a single field or separate fields
    const loginCredential = (identifier || collegeEmail || studentId || '').trim();

    if (!loginCredential) {
      return res.status(400).json({
        success: false,
        message: 'Please provide your College Email or Student ID.'
      });
    }

    if (!password || !password.trim()) {
      return res.status(400).json({
        success: false,
        message: 'Password is required.'
      });
    }

    // Search by collegeEmail (case-insensitive) OR studentId (uppercase)
    const isEmail = emailRegex.test(loginCredential);
    const query = isEmail
      ? { collegeEmail: loginCredential.toLowerCase() }
      : {
          $or: [
            { collegeEmail: loginCredential.toLowerCase() },
            { studentId: loginCredential.toUpperCase() }
          ]
        };

    const student = await Student.findOne(query).select('+password');

    if (!student) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials. No student found matching the provided identifier.'
      });
    }

    // Check password
    const isMatch = await student.comparePassword(password.trim());
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid password. Please check your credentials and try again.'
      });
    }

    const token = generateToken(student);

    return res.status(200).json({
      success: true,
      message: 'Login successful.',
      token,
      student: sanitizeStudent(student)
    });
  } catch (error) {
    console.error('[Login Error]:', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Internal server error during authentication.'
    });
  }
};

module.exports = {
  signup,
  login
};
