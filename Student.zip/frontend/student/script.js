/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * Master Script Entry Point
 * 
 * Provides global configuration and initialization hooks.
 */

window.STUDENT_PORTAL_CONFIG = {
  version: "1.0.0",
  portalName: "College Placement Cell — Student Portal",
  apiBaseUrl: "/api/v1", // Ready for future backend connection
  aiEndpointUrl: "/api/chatbot/query"
};

console.log(`${window.STUDENT_PORTAL_CONFIG.portalName} (v${window.STUDENT_PORTAL_CONFIG.version}) initialized.`);
