/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * Notifications Page Controller
 */

let allNotifications = [];
let currentFilter = 'all';

document.addEventListener('DOMContentLoaded', async () => {
  await initNotificationsPage();
  setupNotificationFilters();
});

async function initNotificationsPage() {
  try {
    allNotifications = await window.StorageService.getNotifications();
    renderNotificationsList();
    updateUnreadCounter();
  } catch (err) {
    console.error("Failed to load notifications:", err);
    window.showToast("Error", "Could not load notifications.", "error");
  }
}

function updateUnreadCounter() {
  const unreadCount = allNotifications.filter(n => !n.read).length;
  const countEl = document.getElementById('notif-unread-count');
  if (countEl) countEl.textContent = `${unreadCount} unread`;
}

function setupNotificationFilters() {
  const filterTabs = document.querySelectorAll('.notif-filter-tab');
  const markAllBtn = document.getElementById('mark-all-read-btn');

  filterTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      filterTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentFilter = tab.getAttribute('data-filter') || 'all';
      renderNotificationsList();
    });
  });

  if (markAllBtn) {
    markAllBtn.addEventListener('click', async () => {
      allNotifications = await window.StorageService.markAllNotificationsAsRead();
      renderNotificationsList();
      updateUnreadCounter();
      window.syncNotificationBadges();
      window.showToast("Notifications", "All notifications marked as read.", "success");
    });
  }
}

function renderNotificationsList() {
  const container = document.getElementById('notifications-container');
  if (!container) return;

  let filtered = allNotifications;
  if (currentFilter === 'unread') {
    filtered = allNotifications.filter(n => !n.read);
  } else if (currentFilter === 'drive') {
    filtered = allNotifications.filter(n => n.type === 'drive');
  } else if (currentFilter === 'application') {
    filtered = allNotifications.filter(n => n.type === 'application' || n.type === 'interview');
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
        </div>
        <div class="empty-title">No notifications</div>
        <div class="empty-description">You're all caught up! There are no notifications matching this filter.</div>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(notif => {
    const iconData = getNotifIcon(notif.type);
    return `
      <div class="notification-card-item ${notif.read ? 'read' : 'unread'}" onclick="handleNotifClick('${notif.id}')">
        <div class="notif-type-icon" style="background-color: ${iconData.bg}; color: ${iconData.color};">
          ${iconData.svg}
        </div>
        <div class="notif-content">
          <div class="notif-title-row">
            <span class="notif-title">${window.escapeHtml(notif.title)}</span>
            <span class="notif-time">${window.escapeHtml(notif.timeAgo || notif.date)}</span>
          </div>
          <p class="notif-message">${window.escapeHtml(notif.message)}</p>
        </div>
        <div style="display: flex; align-items: center; gap: 0.5rem;" onclick="event.stopPropagation();">
          <button class="btn btn-secondary btn-sm btn-icon" title="Delete Notification" onclick="deleteNotificationItem('${notif.id}')">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          </button>
        </div>
      </div>
    `;
  }).join('');
}

async function handleNotifClick(notifId) {
  const notif = allNotifications.find(n => n.id === notifId);
  if (notif && !notif.read) {
    allNotifications = await window.StorageService.markNotificationAsRead(notifId);
    renderNotificationsList();
    updateUnreadCounter();
    window.syncNotificationBadges();
  }
}
window.handleNotifClick = handleNotifClick;

async function deleteNotificationItem(notifId) {
  allNotifications = await window.StorageService.deleteNotification(notifId);
  renderNotificationsList();
  updateUnreadCounter();
  window.syncNotificationBadges();
  window.showToast("Deleted", "Notification removed.", "info");
}
window.deleteNotificationItem = deleteNotificationItem;

function getNotifIcon(type) {
  switch (type) {
    case 'interview':
      return {
        bg: 'var(--warning-100)',
        color: 'var(--warning-700)',
        svg: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>`
      };
    case 'drive':
      return {
        bg: 'var(--primary-100)',
        color: 'var(--primary-700)',
        svg: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>`
      };
    case 'deadline':
      return {
        bg: 'var(--danger-100)',
        color: 'var(--danger-700)',
        svg: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>`
      };
    case 'application':
      return {
        bg: 'var(--info-100)',
        color: 'var(--info-700)',
        svg: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>`
      };
    default:
      return {
        bg: 'var(--bg-surface-secondary)',
        color: 'var(--text-secondary)',
        svg: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`
      };
  }
}
