/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * Storage & Data Access Service (Simulated REST API Layer)
 * 
 * Provides an asynchronous Promise-based API for all portal resources.
 * Future integration: Replace localStorage read/writes with fetch('/api/...')
 */

const STORAGE_KEYS = {
  STUDENT: 'placement_student_profile',
  DRIVES: 'placement_drives_data',
  APPLICATIONS: 'placement_applications_data',
  NOTIFICATIONS: 'placement_notifications_data',
  SETTINGS: 'placement_student_settings',
  CHAT_HISTORY: 'placement_chat_history'
};

const StorageService = {
  // Initialize storage with seed data if not present
  init() {
    // If student profile is missing or is the old dummy Aarav Sharma data, initialize blank profile
    const existingStudent = localStorage.getItem(STORAGE_KEYS.STUDENT);
    if (!existingStudent || (existingStudent && existingStudent.includes("Aarav Sharma"))) {
      localStorage.setItem(STORAGE_KEYS.STUDENT, JSON.stringify(window.SEED_DATA.student));
    }
    if (!localStorage.getItem(STORAGE_KEYS.DRIVES)) {
      localStorage.setItem(STORAGE_KEYS.DRIVES, JSON.stringify(window.SEED_DATA.placementDrives));
    }
    if (!localStorage.getItem(STORAGE_KEYS.APPLICATIONS) || (localStorage.getItem(STORAGE_KEYS.APPLICATIONS) && localStorage.getItem(STORAGE_KEYS.APPLICATIONS).includes("Aarav Sharma"))) {
      localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify([]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS)) {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(window.SEED_DATA.notifications));
    }
    if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
      const defaultSettings = {
        theme: 'light',
        placementAlerts: true,
        applicationUpdates: true,
        interviewAlerts: true,
        deadlineReminders: true,
        allowRecruiterVisibility: true,
        smsAlerts: false
      };
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(defaultSettings));
    }
  },

  // --------------------------------------------------------------------------
  // STUDENT PROFILE API
  // --------------------------------------------------------------------------
  async getStudent() {
    this.init();

    // Check if there is an active session
    let activeEmail = null;
    let activeId = null;
    if (window.AuthService) {
      const session = window.AuthService.getSession();
      if (session) {
        if (session.email) activeEmail = session.email.trim().toLowerCase();
        if (session.studentId) activeId = session.studentId.trim().toUpperCase();
      }
    }

    // 1. Look up student profile by user email
    if (activeEmail) {
      const emailData = localStorage.getItem('student_profile_' + activeEmail);
      if (emailData) {
        try {
          const parsed = JSON.parse(emailData);
          if (parsed && typeof parsed === 'object') return parsed;
        } catch (e) {}
      }
    }

    // 2. Look up student profile by student ID
    if (activeId) {
      const idData = localStorage.getItem('student_profile_' + activeId);
      if (idData) {
        try {
          const parsed = JSON.parse(idData);
          if (parsed && typeof parsed === 'object') return parsed;
        } catch (e) {}
      }
    }

    // 3. Fall back to active student key
    const data = localStorage.getItem(STORAGE_KEYS.STUDENT);
    try {
      const parsed = JSON.parse(data);
      if (parsed) return parsed;
    } catch (e) {}
    return { ...window.SEED_DATA.student };
  },

  async setStudent(studentData) {
    studentData.profileCompletion = this.calculateProfileCompletion(studentData);
    localStorage.setItem(STORAGE_KEYS.STUDENT, JSON.stringify(studentData));

    // Permanently persist under user's email and studentId
    const email = (studentData.email || '').trim().toLowerCase();
    if (email) {
      localStorage.setItem('student_profile_' + email, JSON.stringify(studentData));
    }
    const studentId = (studentData.id || '').trim().toUpperCase();
    if (studentId) {
      localStorage.setItem('student_profile_' + studentId, JSON.stringify(studentData));
    }

    return studentData;
  },

  async updateStudent(updatedData) {
    this.init();
    const current = await this.getStudent();
    const merged = { ...current, ...updatedData };
    
    // Recalculate profile completion
    merged.profileCompletion = this.calculateProfileCompletion(merged);
    
    // 1. Save to active student key
    localStorage.setItem(STORAGE_KEYS.STUDENT, JSON.stringify(merged));

    // 2. CRITICAL: Save to student-specific email and ID keys so it persists across logout/login
    const email = (merged.email || (window.AuthService && window.AuthService.getSession()?.email) || '').trim().toLowerCase();
    if (email) {
      localStorage.setItem('student_profile_' + email, JSON.stringify(merged));
    }
    const studentId = (merged.id || (window.AuthService && window.AuthService.getSession()?.studentId) || '').trim().toUpperCase();
    if (studentId) {
      localStorage.setItem('student_profile_' + studentId, JSON.stringify(merged));
    }

    // 3. Update session if active
    if (window.AuthService) {
      const session = window.AuthService.getSession();
      if (session) {
        session.name = merged.name || session.name;
        session.email = merged.email || session.email;
        session.studentId = merged.id || session.studentId;
        session.department = merged.department || "";
        session.course = merged.course || "";
        const authKey = 'student_portal_session';
        if (localStorage.getItem(authKey)) localStorage.setItem(authKey, JSON.stringify(session));
        if (sessionStorage.getItem(authKey)) sessionStorage.setItem(authKey, JSON.stringify(session));
      }
    }

    // 4. Sync with Backend API if online
    try {
      const session = window.AuthService?.getSession();
      if (session && session.token && !session.token.startsWith('demo-jwt-')) {
        await fetch('http://localhost:5000/api/profile/me', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.token}`
          },
          body: JSON.stringify({
            fullName: merged.name,
            studentId: merged.id,
            phoneNumber: merged.phone,
            dateOfBirth: merged.dob,
            gender: merged.gender,
            courseDegree: merged.course,
            department: merged.department,
            semesterYear: (merged.year || merged.semester) ? `${merged.year || ''} (${merged.semester || ''})`.trim() : '',
            cgpa: merged.cgpa
          })
        });
      }
    } catch (apiErr) {
      // Backend not running or network failed -> local email persistence ensures data is safe
    }

    return merged;
  },

  calculateProfileCompletion(student) {
    if (!student) return 0;
    let filled = 0;
    const fields = [
      student.name && student.name.trim().length > 0,
      student.id && student.id.trim().length > 0,
      student.email && student.email.trim().length > 0,
      student.phone && student.phone.trim().length > 0,
      student.dob && student.dob.trim().length > 0,
      student.gender && student.gender.trim().length > 0,
      student.course && student.course.trim().length > 0,
      student.department && student.department.trim().length > 0,
      student.year && student.year.trim().length > 0,
      student.semester && student.semester.trim().length > 0,
      student.cgpa !== null && student.cgpa !== undefined && !isNaN(student.cgpa) && student.cgpa > 0,
      student.tenthPercentage !== null && student.tenthPercentage !== undefined && !isNaN(student.tenthPercentage) && student.tenthPercentage > 0,
      student.twelfthPercentage !== null && student.twelfthPercentage !== undefined && !isNaN(student.twelfthPercentage) && student.twelfthPercentage > 0,
      student.skills && student.skills.length > 0,
      student.resume && student.resume.fileName
    ];

    fields.forEach(f => {
      if (f) filled++;
    });

    if (filled === 0) return 0;
    return Math.round((filled / fields.length) * 100);
  },

  // --------------------------------------------------------------------------
  // PLACEMENT DRIVES API
  // --------------------------------------------------------------------------
  async getDrives() {
    this.init();
    const data = localStorage.getItem(STORAGE_KEYS.DRIVES);
    return JSON.parse(data) || [];
  },

  async getDriveById(driveId) {
    const drives = await this.getDrives();
    return drives.find(d => d.id === driveId) || null;
  },

  // --------------------------------------------------------------------------
  // APPLICATIONS API
  // --------------------------------------------------------------------------
  async getApplications() {
    this.init();
    const data = localStorage.getItem(STORAGE_KEYS.APPLICATIONS);
    return JSON.parse(data) || [];
  },

  async applyToDrive(driveId) {
    this.init();
    const student = await this.getStudent();
    const drive = await this.getDriveById(driveId);
    
    if (!drive) throw new Error("Placement drive not found.");

    // Check CGPA Eligibility
    if (student.cgpa < drive.minCgpa) {
      throw new Error(`Minimum CGPA requirement is ${drive.minCgpa}. Your current CGPA is ${student.cgpa}.`);
    }

    const apps = await this.getApplications();
    const existing = apps.find(a => a.driveId === driveId);
    if (existing) {
      throw new Error(`You have already applied for ${drive.companyName} (${existing.status}).`);
    }

    const newApp = {
      id: "APP-2026-" + Math.floor(100 + Math.random() * 900),
      driveId: drive.id,
      companyName: drive.companyName,
      companyLogoText: drive.companyLogoText,
      role: drive.role,
      appliedDate: new Date().toISOString().split('T')[0],
      status: "Applied",
      currentStage: "Application Submitted",
      nextStep: "Placement Cell will verify eligibility within 48 hours.",
      interviewDate: null,
      history: [
        { stage: "Applied", date: new Date().toISOString().split('T')[0], status: "completed", notes: "Application submitted via Student Portal." },
        { stage: "Under Review", date: "Pending", status: "active", notes: "Eligibility verification." },
        { stage: "Assessment", date: "Pending", status: "pending", notes: "Awaiting schedule." },
        { stage: "Interview", date: "Pending", status: "pending", notes: "Technical interview." },
        { stage: "Decision", date: "Pending", status: "pending", notes: "Final selection." }
      ]
    };

    apps.unshift(newApp);
    localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));

    // Create a new notification for application submission
    await this.addNotification({
      title: `Applied to ${drive.companyName}`,
      message: `Your application for ${drive.role} at ${drive.companyName} has been submitted successfully. Track status under My Applications.`,
      type: "application"
    });

    return newApp;
  },

  // --------------------------------------------------------------------------
  // NOTIFICATIONS API
  // --------------------------------------------------------------------------
  async getNotifications() {
    this.init();
    const data = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    return JSON.parse(data) || [];
  },

  async addNotification({ title, message, type = "announcement" }) {
    const notifs = await this.getNotifications();
    const newNotif = {
      id: "NOTIF-" + Date.now(),
      title,
      message,
      type,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      timeAgo: "Just now",
      read: false
    };
    notifs.unshift(newNotif);
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifs));
    return newNotif;
  },

  async markNotificationAsRead(id) {
    const notifs = await this.getNotifications();
    const updated = notifs.map(n => n.id === id ? { ...n, read: true } : n);
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(updated));
    return updated;
  },

  async markAllNotificationsAsRead() {
    const notifs = await this.getNotifications();
    const updated = notifs.map(n => ({ ...n, read: true }));
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(updated));
    return updated;
  },

  async deleteNotification(id) {
    const notifs = await this.getNotifications();
    const updated = notifs.filter(n => n.id !== id);
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(updated));
    return updated;
  },

  async getUnreadCount() {
    const notifs = await this.getNotifications();
    return notifs.filter(n => !n.read).length;
  },

  // --------------------------------------------------------------------------
  // SETTINGS API
  // --------------------------------------------------------------------------
  async getSettings() {
    this.init();
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return JSON.parse(data);
  },

  async updateSettings(newSettings) {
    this.init();
    const current = await this.getSettings();
    const merged = { ...current, ...newSettings };
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(merged));
    return merged;
  },

  // --------------------------------------------------------------------------
  // CHATBOT HISTORY API
  // --------------------------------------------------------------------------
  getChatHistory() {
    const data = sessionStorage.getItem(STORAGE_KEYS.CHAT_HISTORY);
    return data ? JSON.parse(data) : null;
  },

  saveChatHistory(history) {
    sessionStorage.setItem(STORAGE_KEYS.CHAT_HISTORY, JSON.stringify(history));
  },

  clearChatHistory() {
    sessionStorage.removeItem(STORAGE_KEYS.CHAT_HISTORY);
  }
};

window.StorageService = StorageService;
