/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * Central Mock Data & Schema Definitions
 * Structured to map 1-to-1 with future REST API & Database models.
 */

const SEED_DATA = {
  // Blank / Fresh Student Profile Model for New Logins
  student: {
    id: "",
    name: "",
    email: "",
    phone: "",
    dob: "",
    gender: "",
    department: "",
    course: "",
    year: "",
    semester: "",
    cgpa: null,
    tenthPercentage: null,
    twelfthPercentage: null,
    activeBacklogs: 0,
    skills: [],
    softSkills: [],
    resume: null,
    certifications: [],
    projects: [],
    preferredRoles: [],
    profileCompletion: 0
  },

  // Placement Drive Opportunities Model
  placementDrives: [
    {
      id: "DRIVE-2026-001",
      companyId: "COMP-001",
      companyName: "Google India",
      companyLogoText: "G",
      role: "Software Engineering Intern / FTE",
      package: "₹32.0 - ₹38.0 LPA",
      minCgpa: 8.0,
      eligibilityDept: ["Computer Science & Engineering", "Information Technology", "Electronics & Communication"],
      requiredSkills: ["Data Structures", "Algorithms", "C++", "Java", "Python", "Problem Solving"],
      location: "Bangalore / Hyderabad",
      driveDate: "2026-09-24",
      deadline: "2026-09-18",
      rounds: [
        "Online Coding Assessment (90 mins)",
        "Technical Interview Round 1 (Data Structures)",
        "Technical Interview Round 2 (System Design & Code)",
        "Googliness & Leadership Fitment"
      ],
      description: "Join Google as a Software Engineer to tackle real-world engineering challenges at hyper-scale. You will develop next-generation technologies that change how billions of users connect, explore, and interact with information.",
      vacancies: 15,
      isFeatured: true,
      status: "Active"
    },
    {
      id: "DRIVE-2026-002",
      companyId: "COMP-002",
      companyName: "Microsoft",
      companyLogoText: "M",
      role: "Software Development Engineer (SDE-1)",
      package: "₹28.5 - ₹34.0 LPA",
      minCgpa: 7.5,
      eligibilityDept: ["Computer Science & Engineering", "Information Technology", "Electronics & Communication", "Electrical Engineering"],
      requiredSkills: ["Algorithms", "Object-Oriented Design", "C#", "C++", "Cloud Basics"],
      location: "Hyderabad / Noida",
      driveDate: "2026-09-28",
      deadline: "2026-09-20",
      rounds: [
        "Online Assessment (3 Coding Questions)",
        "Technical Round 1 (Problem Solving & DSA)",
        "Technical Round 2 (Systems & OOP)",
        "AA / Hiring Manager Discussion"
      ],
      description: "Microsoft is looking for passionate engineers to build global cloud infrastructure and consumer productivity experiences. Work on Azure, Microsoft 365, and AI-powered developer tooling.",
      vacancies: 20,
      isFeatured: true,
      status: "Active"
    },
    {
      id: "DRIVE-2026-003",
      companyId: "COMP-003",
      companyName: "Cisco Systems",
      companyLogoText: "CS",
      role: "Network & Software Engineer",
      package: "₹18.0 - ₹22.0 LPA",
      minCgpa: 7.0,
      eligibilityDept: ["Computer Science & Engineering", "Information Technology", "Electronics & Communication"],
      requiredSkills: ["Networking (TCP/IP)", "Python", "Linux", "Data Structures"],
      location: "Bangalore",
      driveDate: "2026-10-02",
      deadline: "2026-09-22",
      rounds: [
        "Aptitude & Technical MCQ Test",
        "Coding & Network Simulation Round",
        "Technical Panel Interview",
        "HR Interview"
      ],
      description: "Cisco's engineering teams create transformative networking, security, and cloud technologies. Be part of the team powering the future of the internet.",
      vacancies: 25,
      isFeatured: false,
      status: "Active"
    },
    {
      id: "DRIVE-2026-004",
      companyId: "COMP-004",
      companyName: "Deloitte USI",
      companyLogoText: "D",
      role: "Technology Analyst",
      package: "₹9.5 - ₹12.0 LPA",
      minCgpa: 6.5,
      eligibilityDept: ["Computer Science & Engineering", "Information Technology", "Electronics & Communication", "Mechanical", "Civil"],
      requiredSkills: ["SQL", "Python", "Data Analysis", "Cloud Fundamentals", "Communication"],
      location: "Hyderabad / Mumbai / Gurgaon",
      driveDate: "2026-10-05",
      deadline: "2026-09-26",
      rounds: [
        "Cognitive & Technical MCQ Assessment",
        "Technical & Case Study Interview",
        "Partner/HR Discussion"
      ],
      description: "Deloitte Technology Consulting delivers high-impact digital solutions to global enterprise clients. Opportunities in Cloud, Analytics, and Modern Application Development.",
      vacancies: 40,
      isFeatured: false,
      status: "Active"
    },
    {
      id: "DRIVE-2026-005",
      companyId: "COMP-005",
      companyName: "TCS Digital",
      companyLogoText: "TCS",
      role: "Digital Software Engineer",
      package: "₹7.5 - ₹9.0 LPA",
      minCgpa: 6.0,
      eligibilityDept: ["Computer Science & Engineering", "Information Technology", "Electronics & Communication", "Electrical Engineering"],
      requiredSkills: ["Java", "Python", "Web Technologies", "Database Management"],
      location: "Pan India",
      driveDate: "2026-10-10",
      deadline: "2026-09-30",
      rounds: [
        "National Qualifier Test (NQT)",
        "Advanced Coding Test",
        "Combined Tech + HR Interview"
      ],
      description: "TCS Digital offers premier engineering positions for students with proven skills in cutting-edge digital domains like Cloud, AI, and Big Data.",
      vacancies: 60,
      isFeatured: false,
      status: "Active"
    },
    {
      id: "DRIVE-2026-006",
      companyId: "COMP-006",
      companyName: "Amazon AWS",
      companyLogoText: "A",
      role: "Cloud Support Associate",
      package: "₹14.0 - ₹18.0 LPA",
      minCgpa: 7.0,
      eligibilityDept: ["Computer Science & Engineering", "Information Technology", "Electronics & Communication"],
      requiredSkills: ["Linux", "Networking", "Scripting", "Troubleshooting", "AWS Fundamentals"],
      location: "Bangalore / Hyderabad",
      driveDate: "2026-10-14",
      deadline: "2026-10-01",
      rounds: [
        "Online Assessment (Networking & OS)",
        "Technical Virtual Interview 1",
        "Bar Raiser Behavioral & Technical Round"
      ],
      description: "AWS Cloud Support teams provide world-class technical support to global builders and enterprises architecting workloads on AWS.",
      vacancies: 18,
      isFeatured: false,
      status: "Active"
    }
  ],

  // Student's Existing Applications Model
  applications: [
    {
      id: "APP-2026-091",
      driveId: "DRIVE-2026-001",
      companyName: "Google India",
      companyLogoText: "G",
      role: "Software Engineering Intern / FTE",
      appliedDate: "2026-09-02",
      status: "Shortlisted", // Possible: Applied, Under Review, Shortlisted, Assessment, Interview, Selected, Rejected
      currentStage: "Technical Interview Round 1",
      nextStep: "Technical Interview on Sep 14, 2026 at 11:00 AM (Google Meet link dispatched to email)",
      interviewDate: "2026-09-14",
      history: [
        { stage: "Applied", date: "2026-09-02", status: "completed", notes: "Application submitted with verified resume." },
        { stage: "Under Review", date: "2026-09-04", status: "completed", notes: "Profile and CGPA verified by Placement Cell." },
        { stage: "Shortlisted", date: "2026-09-07", status: "completed", notes: "Shortlisted for technical interview based on online assessment." },
        { stage: "Interview", date: "2026-09-14", status: "active", notes: "Round 1 DSA scheduled." },
        { stage: "Decision", date: "Pending", status: "pending", notes: "Final result notification." }
      ]
    },
    {
      id: "APP-2026-084",
      driveId: "DRIVE-2026-002",
      companyName: "Microsoft",
      companyLogoText: "M",
      role: "Software Development Engineer (SDE-1)",
      appliedDate: "2026-09-03",
      status: "Assessment",
      currentStage: "Online Assessment Scheduled",
      nextStep: "Codility Test Link active on Sep 15, 2026 (02:00 PM to 04:00 PM)",
      interviewDate: "2026-09-22",
      history: [
        { stage: "Applied", date: "2026-09-03", status: "completed", notes: "Application submitted successfully." },
        { stage: "Under Review", date: "2026-09-05", status: "completed", notes: "Eligibility criteria matched." },
        { stage: "Assessment", date: "2026-09-15", status: "active", notes: "3 Coding challenges on Codility." },
        { stage: "Interview", date: "Pending", status: "pending", notes: "Awaiting test results." },
        { stage: "Decision", date: "Pending", status: "pending", notes: "Final selection." }
      ]
    },
    {
      id: "APP-2026-072",
      driveId: "DRIVE-2026-003",
      companyName: "Cisco Systems",
      companyLogoText: "CS",
      role: "Network & Software Engineer",
      appliedDate: "2026-08-28",
      status: "Under Review",
      currentStage: "Eligibility Verification",
      nextStep: "Placement Officer review in progress. Shortlist will be posted by Sep 12.",
      interviewDate: null,
      history: [
        { stage: "Applied", date: "2026-08-28", status: "completed", notes: "Applied via Student Portal." },
        { stage: "Under Review", date: "2026-08-30", status: "active", notes: "Academic records verification." },
        { stage: "Assessment", date: "Pending", status: "pending", notes: "Campus test." },
        { stage: "Interview", date: "Pending", status: "pending", notes: "Technical round." },
        { stage: "Decision", date: "Pending", status: "pending", notes: "Final result." }
      ]
    },
    {
      id: "APP-2026-061",
      companyName: "Oracle India",
      companyLogoText: "O",
      role: "Member of Technical Staff",
      appliedDate: "2026-08-10",
      status: "Selected",
      currentStage: "Offer Letter Issued",
      nextStep: "Complete documentation in placement office before Sep 20.",
      interviewDate: "2026-08-22",
      history: [
        { stage: "Applied", date: "2026-08-10", status: "completed", notes: "Applied." },
        { stage: "Assessment", date: "2026-08-14", status: "completed", notes: "Cleared with 96% score." },
        { stage: "Interview", date: "2026-08-22", status: "completed", notes: "Cleared 2 technical rounds + HR." },
        { stage: "Decision", date: "2026-08-25", status: "completed", notes: "OFFER EXTENDED: ₹17.5 LPA CTC." }
      ]
    }
  ],

  // Notifications Model
  notifications: [
    {
      id: "NOTIF-001",
      title: "Google Technical Interview Scheduled",
      message: "Your Technical Interview Round 1 for Google India (SWE) is scheduled on Sep 14, 2026 at 11:00 AM IST via Google Meet.",
      type: "interview", // drive, application, interview, deadline, announcement
      date: "2026-09-08 08:30",
      timeAgo: "2 hours ago",
      read: false
    },
    {
      id: "NOTIF-002",
      title: "New Drive: Amazon AWS Hiring",
      message: "Amazon AWS has announced a campus drive for Cloud Support Associate (₹14.0 - ₹18.0 LPA). Application deadline: Oct 01, 2026.",
      type: "drive",
      date: "2026-09-07 16:45",
      timeAgo: "Yesterday",
      read: false
    },
    {
      id: "NOTIF-003",
      title: "Microsoft Assessment Link Available",
      message: "The Online Assessment for Microsoft SDE-1 will be held on Sep 15, 2026. Make sure your system meets the camera & browser requirements.",
      type: "application",
      date: "2026-09-06 11:20",
      timeAgo: "2 days ago",
      read: false
    },
    {
      id: "NOTIF-004",
      title: "Urgent: Google Application Deadline Reminder",
      message: "Applications for Google India close in 10 days on Sep 18, 2026 at 11:59 PM. Ensure resume is updated.",
      type: "deadline",
      date: "2026-09-05 10:00",
      timeAgo: "3 days ago",
      read: true
    },
    {
      id: "NOTIF-005",
      title: "Placement Cell Notice: Resume Verification",
      message: "All 4th-year B.Tech students are requested to ensure their 6th-semester mark sheets and resume links are verified by the department coordinator.",
      type: "announcement",
      date: "2026-09-01 09:15",
      timeAgo: "1 week ago",
      read: true
    }
  ],

  // AI Knowledge Base Q&A items
  aiKnowledgeBase: [
    {
      keywords: ["active drives", "current drives", "upcoming drives", "what drives are active"],
      response: "Here are the top active placement drives right now:\n1. **Google India** — Software Engineering Intern / FTE (₹32 - ₹38 LPA) | Deadline: Sep 18\n2. **Microsoft** — SDE-1 (₹28.5 - ₹34 LPA) | Deadline: Sep 20\n3. **Cisco Systems** — Network & Software Engineer (₹18 - ₹22 LPA) | Deadline: Sep 22\n4. **Deloitte USI** — Technology Analyst (₹9.5 - ₹12 LPA) | Deadline: Sep 26\n5. **Amazon AWS** — Cloud Support Associate (₹14 - ₹18 LPA) | Deadline: Oct 01"
    },
    {
      keywords: ["google", "google criteria", "google eligibility", "google package"],
      response: "**Google India Drive Details:**\n• **Role:** Software Engineering Intern / FTE\n• **CTC:** ₹32.0 - ₹38.0 LPA\n• **Eligibility:** B.Tech CSE, IT, ECE with CGPA ≥ 8.0 & 0 active backlogs\n• **Required Skills:** Data Structures, Algorithms, C++/Java/Python, Problem Solving\n• **Drive Date:** Sep 24, 2026 (Deadline: Sep 18, 2026)\n• **Rounds:** Online Coding Test (90 mins) → 2 Technical DSA Rounds → Googliness Fitment."
    },
    {
      keywords: ["microsoft", "microsoft criteria", "microsoft eligibility", "microsoft package"],
      response: "**Microsoft SDE-1 Drive Details:**\n• **Role:** Software Development Engineer (SDE-1)\n• **CTC:** ₹28.5 - ₹34.0 LPA\n• **Eligibility:** B.Tech CSE, IT, ECE, EE with CGPA ≥ 7.5\n• **Required Skills:** Algorithms, System Design basics, OOP (C#/C++/Java)\n• **Application Deadline:** Sep 20, 2026\n• **Assessment Date:** Sep 15, 2026 on Codility."
    },
    {
      keywords: ["prepare", "how to prepare", "interview tips", "preparation"],
      response: "Top tips to prepare for your upcoming placement drives:\n1. **Data Structures & Algorithms:** Practice LeetCode Mediums on Trees, Graphs, Dynamic Programming, and Two Pointers.\n2. **Mock Technical Interviews:** Practice speaking your thought process aloud while writing code.\n3. **Core CS Fundamentals:** Review Operating Systems (Concurrency, Virtual Memory), DBMS (Indexing, Normalization, SQL), and Computer Networks.\n4. **Projects & Resume:** Be ready to explain architecture trade-offs and your specific contributions in detail."
    },
    {
      keywords: ["documents", "document", "what documents", "required documents"],
      response: "Mandatory documents to carry for campus placement drives:\n1. Updated Placement Cell Verified Resume (3 printed copies)\n2. College Student Identity Card & Government Photo ID (Aadhaar / PAN / Passport)\n3. 10th, 12th, and all Semester Mark Sheets (Originals + Photocopies)\n4. Passport size photographs (Formal attire, white background)\n5. Certificates of listed projects & internships"
    }
  ]
};

// Export to window for browser access
window.SEED_DATA = SEED_DATA;
