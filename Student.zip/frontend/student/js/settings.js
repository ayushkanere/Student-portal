/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * Settings & Preferences Controller
 */

let currentSettings = null;

document.addEventListener('DOMContentLoaded', async () => {
  await initSettingsPage();
  setupSettingsNavigation();
  setupSettingsToggles();
  setupPasswordChangeForm();
});

async function initSettingsPage() {
  try {
    currentSettings = await window.StorageService.getSettings();
    const student = await window.StorageService.getStudent();

    // Account Tab Info
    const acctName = document.getElementById('account-student-name');
    const acctEmail = document.getElementById('account-student-email');
    const acctId = document.getElementById('account-student-id');
    const acctDept = document.getElementById('account-student-dept');

    if (acctName) acctName.textContent = student.name || 'Not added yet';
    if (acctEmail) acctEmail.textContent = student.email || 'Not added yet';
    if (acctId) acctId.textContent = student.id || 'Not added yet';
    if (acctDept) {
      const parts = [];
      if (student.course) parts.push(student.course);
      if (student.department) parts.push(student.department);
      acctDept.textContent = parts.length > 0 ? parts.join(' • ') : 'Department not added';
    }

    // Notification Toggles
    setToggle('toggle-placement-alerts', currentSettings.placementAlerts);
    setToggle('toggle-app-updates', currentSettings.applicationUpdates);
    setToggle('toggle-interview-alerts', currentSettings.interviewAlerts);
    setToggle('toggle-deadline-reminders', currentSettings.deadlineReminders);

    // Privacy Toggles
    setToggle('toggle-recruiter-vis', currentSettings.allowRecruiterVisibility);
    setToggle('toggle-sms-alerts', currentSettings.smsAlerts);

    // Theme selector
    const themeSelect = document.getElementById('setting-theme-select');
    if (themeSelect) {
      themeSelect.value = currentSettings.theme || 'light';
      themeSelect.addEventListener('change', async (e) => {
        const chosenTheme = e.target.value;
        document.documentElement.setAttribute('data-theme', chosenTheme);
        await window.StorageService.updateSettings({ theme: chosenTheme });
        window.showToast("Theme Updated", `Switched to ${chosenTheme} theme.`, "info");
      });
    }
  } catch (err) {
    console.error("Failed to load settings:", err);
  }
}

function setToggle(id, checked) {
  const el = document.getElementById(id);
  if (el) el.checked = !!checked;
}

function setupSettingsNavigation() {
  const navBtns = document.querySelectorAll('.settings-nav-btn');
  const sections = document.querySelectorAll('.settings-section-card');

  navBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      navBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      sections.forEach(sec => {
        if (sec.id === targetId) {
          sec.classList.remove('hidden');
        } else {
          sec.classList.add('hidden');
        }
      });
    });
  });
}

function setupSettingsToggles() {
  const toggleConfigs = [
    { id: 'toggle-placement-alerts', key: 'placementAlerts', label: 'Placement drive notifications' },
    { id: 'toggle-app-updates', key: 'applicationUpdates', label: 'Application status alerts' },
    { id: 'toggle-interview-alerts', key: 'interviewAlerts', label: 'Interview reminder notifications' },
    { id: 'toggle-deadline-reminders', key: 'deadlineReminders', label: 'Deadline alerts' },
    { id: 'toggle-recruiter-vis', key: 'allowRecruiterVisibility', label: 'Recruiter profile visibility' },
    { id: 'toggle-sms-alerts', key: 'smsAlerts', label: 'SMS & WhatsApp alerts' }
  ];

  toggleConfigs.forEach(conf => {
    const el = document.getElementById(conf.id);
    if (el) {
      el.addEventListener('change', async () => {
        const update = {};
        update[conf.key] = el.checked;
        await window.StorageService.updateSettings(update);
        window.showToast("Preference Saved", `${conf.label} ${el.checked ? 'enabled' : 'disabled'}.`, "success");
      });
    }
  });
}

function setupPasswordChangeForm() {
  const form = document.getElementById('change-password-form');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const currentPass = document.getElementById('current-password')?.value.trim();
    const newPass = document.getElementById('new-password')?.value.trim();
    const confirmPass = document.getElementById('confirm-password')?.value.trim();
    const errorEl = document.getElementById('password-change-error');

    if (!currentPass || !newPass || !confirmPass) {
      if (errorEl) {
        errorEl.textContent = "Please fill in all password fields.";
        errorEl.style.display = 'block';
      }
      return;
    }

    if (newPass.length < 6) {
      if (errorEl) {
        errorEl.textContent = "New password must be at least 6 characters long.";
        errorEl.style.display = 'block';
      }
      return;
    }

    if (newPass !== confirmPass) {
      if (errorEl) {
        errorEl.textContent = "New passwords do not match.";
        errorEl.style.display = 'block';
      }
      return;
    }

    // In a real production system: POST /api/auth/change-password
    // Here we perform secure client validation and reset form
    form.reset();
    if (errorEl) errorEl.style.display = 'none';

    window.showToast("Password Updated", "Your account password was updated successfully.", "success");
  });
}
