/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * Dashboard Page Logic
 */

document.addEventListener('DOMContentLoaded', async () => {
  await loadDashboardData();
});

async function loadDashboardData() {
  try {
    const student = await window.StorageService.getStudent();
    const drives = await window.StorageService.getDrives();
    const applications = await window.StorageService.getApplications();
    const notifications = await window.StorageService.getNotifications();

    renderWelcomeSection(student);
    renderProfileSummary(student);
    renderPlacementStats(applications);
    renderUpcomingDrives(drives, applications);
    renderRecentNotifications(notifications);
    renderApplicationStatus(applications);
  } catch (err) {
    console.error("Failed to load dashboard data:", err);
    window.showToast("Data Error", "Could not load dashboard data.", "error");
  }
}

/* --------------------------------------------------------------------------
   A. WELCOME SECTION
   -------------------------------------------------------------------------- */
function renderWelcomeSection(student) {
  const welcomeName = document.getElementById('welcome-student-name');
  if (welcomeName) welcomeName.textContent = student.name || 'Student';

  const cgpaPill = document.getElementById('welcome-cgpa-pill');
  if (cgpaPill) {
    cgpaPill.textContent = student.cgpa ? `CGPA: ${student.cgpa} / 10` : 'CGPA: Not added yet';
  }

  const deptPill = document.getElementById('welcome-dept-pill');
  if (deptPill) {
    if (student.course && student.department) {
      deptPill.textContent = `${student.course} - ${student.department}`;
    } else if (student.department || student.course) {
      deptPill.textContent = student.department || student.course;
    } else {
      deptPill.textContent = 'Department: Not added yet';
    }
  }

  const backlogsPill = document.getElementById('welcome-backlogs-pill');
  if (backlogsPill) {
    backlogsPill.textContent = `Active Backlogs: ${student.activeBacklogs !== undefined && student.activeBacklogs !== null ? student.activeBacklogs : 0}`;
  }

  // Profile Incomplete CTA Banner
  const ctaBanner = document.getElementById('profile-cta-banner');
  const completion = student.profileCompletion || 0;
  if (ctaBanner) {
    if (completion < 50 || !student.course || !student.cgpa) {
      ctaBanner.classList.remove('hidden');
      ctaBanner.innerHTML = `
        <div class="card" style="background: linear-gradient(135deg, rgba(245, 158, 11, 0.08), rgba(239, 68, 68, 0.08)); border: 1px solid var(--warning-500); padding: 1rem 1.35rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem; border-radius: var(--radius-lg); margin-bottom: 0.5rem;">
          <div style="display: flex; align-items: center; gap: 0.85rem;">
            <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--warning-100); color: var(--warning-700); display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0;">⚠️</div>
            <div>
              <div style="font-weight: 700; color: var(--text-primary); font-size: 0.95rem;">Action Required: Your Placement Profile is Incomplete (${completion}%)</div>
              <div style="font-size: 0.825rem; color: var(--text-muted); margin-top: 2px;">Fill in your personal, academic details, and upload your resume so placement coordinators can verify your eligibility for upcoming drives.</div>
            </div>
          </div>
          <a href="profile.html" class="btn btn-primary btn-sm" style="flex-shrink: 0;">
            Complete Profile Now &rarr;
          </a>
        </div>
      `;
    } else {
      ctaBanner.classList.add('hidden');
    }
  }
}

/* --------------------------------------------------------------------------
   B. PROFILE SUMMARY
   -------------------------------------------------------------------------- */
function renderProfileSummary(student) {
  const nameEl = document.getElementById('summary-name');
  const idEl = document.getElementById('summary-id');
  const courseEl = document.getElementById('summary-course');
  const deptEl = document.getElementById('summary-dept');
  const semEl = document.getElementById('summary-sem');
  const cgpaEl = document.getElementById('summary-cgpa');
  const compPercentEl = document.getElementById('summary-completion-percent');
  const compBarEl = document.getElementById('summary-completion-bar');
  const avatarEl = document.getElementById('summary-avatar');

  if (nameEl) nameEl.textContent = student.name || 'Not added yet';
  if (idEl) idEl.textContent = student.id || 'Not added yet';
  if (courseEl) courseEl.textContent = student.course || 'Not added yet';
  if (deptEl) deptEl.textContent = student.department || 'Not added yet';
  
  if (semEl) {
    if (student.year || student.semester) {
      semEl.textContent = `${student.year || ''} (${student.semester || ''})`.trim();
    } else {
      semEl.textContent = 'Not added yet';
    }
  }

  if (cgpaEl) {
    cgpaEl.textContent = (student.cgpa !== null && student.cgpa !== undefined) ? student.cgpa : '--';
  }
  
  if (avatarEl) {
    if (student.name && student.name.trim()) {
      avatarEl.textContent = student.name.trim().split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
    } else if (student.email) {
      avatarEl.textContent = student.email.substring(0, 2).toUpperCase();
    } else {
      avatarEl.textContent = 'ST';
    }
  }

  const completion = student.profileCompletion || 0;
  if (compPercentEl) compPercentEl.textContent = `${completion}%`;
  if (compBarEl) compBarEl.style.width = `${completion}%`;
}

/* --------------------------------------------------------------------------
   C. PLACEMENT STATISTICS
   -------------------------------------------------------------------------- */
function renderPlacementStats(applications) {
  const total = applications.length;
  const active = applications.filter(a => ['Applied', 'Under Review', 'Assessment', 'Interview'].includes(a.status)).length;
  const shortlisted = applications.filter(a => a.status === 'Shortlisted').length;
  const selected = applications.filter(a => a.status === 'Selected').length;

  const totalEl = document.getElementById('stat-total-apps');
  const activeEl = document.getElementById('stat-active-apps');
  const shortlistedEl = document.getElementById('stat-shortlisted-apps');
  const selectedEl = document.getElementById('stat-selected-apps');

  if (totalEl) totalEl.textContent = total;
  if (activeEl) activeEl.textContent = active;
  if (shortlistedEl) shortlistedEl.textContent = shortlisted;
  if (selectedEl) selectedEl.textContent = selected;
}

/* --------------------------------------------------------------------------
   D. UPCOMING PLACEMENT DRIVES
   -------------------------------------------------------------------------- */
function renderUpcomingDrives(drives, applications) {
  const container = document.getElementById('dashboard-drives-list');
  if (!container) return;

  const appliedDriveIds = applications.map(a => a.driveId);
  const topDrives = drives.slice(0, 3); // Top 3 drives

  container.innerHTML = topDrives.map(drive => {
    const isApplied = appliedDriveIds.includes(drive.id);
    return `
      <div class="drive-item-card">
        <div class="company-logo-badge">${escapeHtml(drive.companyLogoText)}</div>
        <div class="drive-main-info">
          <div class="drive-company-name">${escapeHtml(drive.companyName)}</div>
          <div class="drive-job-role">${escapeHtml(drive.role)}</div>
          <div class="drive-tags-row">
            <span class="drive-meta-badge drive-package-badge">${escapeHtml(drive.package)}</span>
            <span class="drive-meta-badge">Min CGPA: ${drive.minCgpa}</span>
            <span class="drive-meta-badge">Deadline: ${formatDate(drive.deadline)}</span>
          </div>
        </div>
        <div>
          ${isApplied 
            ? `<span class="badge badge-success">Applied</span>`
            : `<button class="btn btn-primary btn-sm" onclick="quickApplyFromDashboard('${drive.id}')">Apply Now</button>`
          }
        </div>
      </div>
    `;
  }).join('');
}

async function quickApplyFromDashboard(driveId) {
  try {
    await window.StorageService.applyToDrive(driveId);
    window.showToast("Application Successful!", "Your application was submitted. Good luck!", "success");
    await loadDashboardData();
    window.syncNotificationBadges();
  } catch (err) {
    window.showToast("Application Notice", err.message, "warning");
  }
}
window.quickApplyFromDashboard = quickApplyFromDashboard;

/* --------------------------------------------------------------------------
   E. RECENT NOTIFICATIONS
   -------------------------------------------------------------------------- */
function renderRecentNotifications(notifications) {
  const container = document.getElementById('dashboard-notifications-list');
  if (!container) return;

  const recent = notifications.slice(0, 3);
  if (recent.length === 0) {
    container.innerHTML = `<div class="text-muted" style="padding: 1rem; text-align: center;">No new notifications.</div>`;
    return;
  }

  container.innerHTML = recent.map(notif => `
    <div style="padding: 0.85rem; border-radius: var(--radius-md); background-color: var(--bg-surface-secondary); margin-bottom: 0.65rem; border-left: 3px solid var(--primary-500);">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.25rem;">
        <span style="font-weight: 600; font-size: 0.85rem; color: var(--text-primary);">${escapeHtml(notif.title)}</span>
        <span style="font-size: 0.72rem; color: var(--text-subtle);">${escapeHtml(notif.timeAgo)}</span>
      </div>
      <p style="font-size: 0.8rem; color: var(--text-muted); margin: 0; line-height: 1.4;">${escapeHtml(notif.message)}</p>
    </div>
  `).join('');
}

/* --------------------------------------------------------------------------
   F. APPLICATION STATUS TIMELINE & RECENT TABLE
   -------------------------------------------------------------------------- */
function renderApplicationStatus(applications) {
  const container = document.getElementById('dashboard-applications-table');
  if (!container) return;

  if (applications.length === 0) {
    container.innerHTML = `
      <tr>
        <td colspan="5" class="text-center text-muted" style="padding: 2rem;">
          No active applications found. Explore opportunities to apply!
        </td>
      </tr>
    `;
    return;
  }

  container.innerHTML = applications.slice(0, 4).map(app => `
    <tr>
      <td>
        <div style="display: flex; align-items: center; gap: 0.65rem;">
          <span style="font-weight: 700; width: 28px; height: 28px; border-radius: 6px; background: var(--bg-surface-secondary); display: flex; align-items: center; justify-content: center; font-size: 0.8rem;">
            ${escapeHtml(app.companyLogoText || 'C')}
          </span>
          <span style="font-weight: 600; color: var(--text-primary);">${escapeHtml(app.companyName)}</span>
        </div>
      </td>
      <td>${escapeHtml(app.role)}</td>
      <td>${formatDate(app.appliedDate)}</td>
      <td>
        <span class="badge badge-${app.status.toLowerCase().replace(/\s+/g, '-')}">
          ${escapeHtml(app.status)}
        </span>
      </td>
      <td style="font-size: 0.8rem; color: var(--text-muted); max-width: 260px;">
        ${escapeHtml(app.nextStep || 'In Progress')}
      </td>
    </tr>
  `).join('');
}

function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch (e) {
    return dateStr;
  }
}
