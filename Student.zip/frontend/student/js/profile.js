/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * Student Profile Page Controller
 */

let currentStudent = null;
let isEditMode = false;

document.addEventListener('DOMContentLoaded', async () => {
  await initProfilePage();
  setupSkillsTagEditor();
  setupResumeUpload();
  setupProfileActions();
});

async function initProfilePage() {
  try {
    currentStudent = await window.StorageService.getStudent();
    populateProfileData(currentStudent);
  } catch (err) {
    console.error("Failed to load profile:", err);
    window.showToast("Error", "Could not load profile data.", "error");
  }
}

function populateProfileData(student) {
  if (!student) return;

  // Personal Info
  setFieldVal('prof-name', student.name || '');
  setFieldVal('prof-id', student.id || '');
  setFieldVal('prof-email', student.email || '');
  setFieldVal('prof-phone', student.phone || '');
  setFieldVal('prof-dob', student.dob || '');
  setFieldVal('prof-gender', student.gender || '');

  // Academic Info
  setFieldVal('prof-course', student.course || '');
  setFieldVal('prof-dept', student.department || '');
  setFieldVal('prof-year', student.year || '');
  setFieldVal('prof-sem', student.semester || '');
  setFieldVal('prof-cgpa', (student.cgpa !== undefined && student.cgpa !== null) ? student.cgpa : '');
  setFieldVal('prof-10th', (student.tenthPercentage !== undefined && student.tenthPercentage !== null) ? student.tenthPercentage : '');
  setFieldVal('prof-12th', (student.twelfthPercentage !== undefined && student.twelfthPercentage !== null) ? student.twelfthPercentage : '');
  setFieldVal('prof-backlogs', (student.activeBacklogs !== undefined && student.activeBacklogs !== null) ? student.activeBacklogs : '');

  // Sidebar mini card
  const heroName = document.getElementById('profile-hero-name');
  const heroId = document.getElementById('profile-hero-id');
  const heroDept = document.getElementById('profile-hero-dept');
  const heroAvatar = document.getElementById('profile-hero-avatar');
  const completionPercent = document.getElementById('profile-completion-pct');
  const completionBar = document.getElementById('profile-completion-bar');

  if (heroName) heroName.textContent = student.name && student.name.trim() ? student.name : 'Not added yet';
  if (heroId) heroId.textContent = student.id ? `ID: ${student.id}` : 'ID: Not added yet';
  
  if (heroDept) {
    const parts = [];
    if (student.course) parts.push(student.course);
    if (student.department) parts.push(student.department);
    heroDept.textContent = parts.length > 0 ? parts.join(' • ') : 'Department not added';
  }

  if (heroAvatar) {
    if (student.name && student.name.trim()) {
      const initials = student.name.trim().split(/\s+/).map(n => n[0].toUpperCase()).join('').substring(0, 2);
      heroAvatar.textContent = initials || 'ST';
    } else {
      heroAvatar.textContent = 'ST';
    }
  }

  const comp = student.profileCompletion !== undefined ? student.profileCompletion : 0;
  if (completionPercent) completionPercent.textContent = `${comp}%`;
  if (completionBar) completionBar.style.width = `${comp}%`;

  // Render Skills tags
  renderSkillsTags(student.skills || []);

  // Render Resume File details
  renderResumeDetails(student.resume);

  // Render Projects & Certifications
  renderProjectsAndCerts(student);
}

function setFieldVal(id, val) {
  const el = document.getElementById(id);
  if (el) {
    if (el.tagName === 'INPUT' || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA') {
      el.value = val !== undefined && val !== null ? val : '';
    } else {
      el.textContent = val !== undefined && val !== null ? val : '';
    }
  }
}

/* --------------------------------------------------------------------------
   SKILLS TAG MANAGER
   -------------------------------------------------------------------------- */
function setupSkillsTagEditor() {
  const addBtn = document.getElementById('add-skill-btn');
  const skillInput = document.getElementById('new-skill-input');

  const addSkill = async () => {
    const skill = (skillInput?.value || '').trim();
    if (!skill) return;

    if (!currentStudent.skills) currentStudent.skills = [];
    if (!currentStudent.skills.includes(skill)) {
      currentStudent.skills.push(skill);
      renderSkillsTags(currentStudent.skills);
      skillInput.value = '';
      try {
        const saved = await window.StorageService.updateStudent({ skills: currentStudent.skills });
        currentStudent = saved;
        populateProfileData(saved);
        window.showToast("Skill Added", `Added "${skill}" to your profile.`, "success");
      } catch (e) {
        console.error("Failed to save skill:", e);
      }
    } else {
      window.showToast("Notice", "Skill already added.", "warning");
    }
  };

  if (addBtn) addBtn.addEventListener('click', addSkill);
  if (skillInput) {
    skillInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        addSkill();
      }
    });
  }
}

function renderSkillsTags(skills) {
  const container = document.getElementById('skills-tags-container');
  if (!container) return;

  if (!skills || skills.length === 0) {
    container.innerHTML = `<span class="text-muted" style="font-size: 0.85rem;">No skills added yet. Add relevant technical or soft skills above.</span>`;
    return;
  }

  container.innerHTML = skills.map((s, idx) => `
    <span class="tag-badge">
      ${window.escapeHtml(s)}
      <span class="tag-remove-btn" onclick="removeSkillTag(${idx})">&times;</span>
    </span>
  `).join('');
}

async function removeSkillTag(idx) {
  if (currentStudent && currentStudent.skills && currentStudent.skills[idx] !== undefined) {
    const removed = currentStudent.skills.splice(idx, 1);
    renderSkillsTags(currentStudent.skills);
    try {
      const saved = await window.StorageService.updateStudent({ skills: currentStudent.skills });
      currentStudent = saved;
      populateProfileData(saved);
      window.showToast("Skill Removed", `Removed "${removed[0]}" from your profile.`, "info");
    } catch (e) {
      console.error("Failed to remove skill:", e);
    }
  }
}
window.removeSkillTag = removeSkillTag;

/* --------------------------------------------------------------------------
   RESUME UPLOAD & PREVIEW
   -------------------------------------------------------------------------- */
function setupResumeUpload() {
  const dropZone = document.getElementById('resume-dropzone');
  const fileInput = document.getElementById('resume-file-input');

  if (dropZone && fileInput) {
    dropZone.addEventListener('click', () => fileInput.click());

    dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropZone.classList.add('dragover');
    });

    dropZone.addEventListener('dragleave', () => {
      dropZone.classList.remove('dragover');
    });

    dropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropZone.classList.remove('dragover');
      if (e.dataTransfer.files.length) {
        handleResumeFile(e.dataTransfer.files[0]);
      }
    });

    fileInput.addEventListener('change', () => {
      if (fileInput.files.length) {
        handleResumeFile(fileInput.files[0]);
      }
    });
  }
}

async function handleResumeFile(file) {
  if (!file.name.match(/\.(pdf|docx)$/i)) {
    window.showToast("Invalid File", "Please upload a PDF or DOCX file.", "error");
    return;
  }

  const fileSize = (file.size / 1024).toFixed(0) + " KB";
  const resumeData = {
    fileName: file.name,
    fileSize: fileSize,
    uploadDate: new Date().toISOString().split('T')[0],
    status: "Verified by Placement Cell"
  };

  try {
    const saved = await window.StorageService.updateStudent({ resume: resumeData });
    currentStudent = saved;
    renderResumeDetails(currentStudent.resume);
    populateProfileData(saved);
    window.showToast("Resume Uploaded", `${file.name} uploaded and saved successfully.`, "success");
  } catch (e) {
    console.error("Failed to save resume:", e);
    window.showToast("Upload Error", "Failed to save resume details.", "error");
  }
}

function renderResumeDetails(resume) {
  const container = document.getElementById('resume-details-container');
  if (!container) return;

  if (!resume || !resume.fileName) {
    container.innerHTML = `<div class="text-muted" style="font-size: 0.85rem; padding: 0.5rem 0;">No resume uploaded yet. Complete your profile by uploading your latest CV.</div>`;
    return;
  }

  container.innerHTML = `
    <div class="resume-file-preview">
      <div style="display: flex; align-items: center; gap: 0.85rem;">
        <div style="width: 40px; height: 40px; border-radius: 8px; background: var(--danger-50); color: var(--danger-600); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.75rem;">
          PDF
        </div>
        <div>
          <div style="font-weight: 600; color: var(--text-primary); font-size: 0.9rem;">${window.escapeHtml(resume.fileName)}</div>
          <div style="font-size: 0.75rem; color: var(--text-muted);">${resume.fileSize} • Uploaded on ${resume.uploadDate}</div>
        </div>
      </div>
      <div style="display: flex; gap: 0.5rem;">
        <button class="btn btn-outline btn-sm" onclick="previewResumeModal()">View</button>
        <button class="btn btn-secondary btn-sm" onclick="document.getElementById('resume-file-input').click()">Replace</button>
      </div>
    </div>
  `;
}

function previewResumeModal() {
  if (currentStudent && currentStudent.resume) {
    window.showToast("Resume Preview", `Opening verified resume: ${currentStudent.resume.fileName}`, "info");
  }
}
window.previewResumeModal = previewResumeModal;

/* --------------------------------------------------------------------------
   PROJECTS & CERTIFICATIONS
   -------------------------------------------------------------------------- */
function renderProjectsAndCerts(student) {
  const projContainer = document.getElementById('profile-projects-list');
  const certContainer = document.getElementById('profile-certs-list');

  if (projContainer) {
    if (!student.projects || student.projects.length === 0) {
      projContainer.innerHTML = `<div class="text-muted" style="font-size: 0.85rem; padding: 0.5rem 0;">No projects added yet.</div>`;
    } else {
      projContainer.innerHTML = student.projects.map(p => `
        <div style="padding: 0.85rem; border-radius: var(--radius-md); background-color: var(--bg-surface-secondary); margin-bottom: 0.65rem;">
          <div style="font-weight: 700; font-size: 0.9rem; color: var(--text-primary);">${window.escapeHtml(p.title)}</div>
          <div style="font-size: 0.75rem; color: var(--primary-600); font-weight: 600; margin: 2px 0;">${window.escapeHtml(p.tech)}</div>
          <p style="font-size: 0.825rem; color: var(--text-muted); margin: 0; line-height: 1.4;">${window.escapeHtml(p.desc)}</p>
        </div>
      `).join('');
    }
  }

  if (certContainer) {
    if (!student.certifications || student.certifications.length === 0) {
      certContainer.innerHTML = `<div class="text-muted" style="font-size: 0.85rem; padding: 0.5rem 0;">No certifications added yet.</div>`;
    } else {
      certContainer.innerHTML = student.certifications.map(c => `
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.65rem 0.85rem; border-radius: var(--radius-md); background-color: var(--bg-surface-secondary); margin-bottom: 0.5rem;">
          <div>
            <div style="font-weight: 600; font-size: 0.85rem; color: var(--text-primary);">${window.escapeHtml(c.name)}</div>
            <div style="font-size: 0.75rem; color: var(--text-muted);">${window.escapeHtml(c.issuer)}</div>
          </div>
          <span class="badge badge-primary" style="font-size: 0.72rem;">${c.year}</span>
        </div>
      `).join('');
    }
  }
}

/* --------------------------------------------------------------------------
   EDIT / SAVE PROFILE
   -------------------------------------------------------------------------- */
function setupProfileActions() {
  const editBtn = document.getElementById('edit-profile-btn');
  const saveBtn = document.getElementById('save-profile-btn');
  const cancelBtn = document.getElementById('cancel-profile-btn');

  if (editBtn) {
    editBtn.addEventListener('click', () => {
      isEditMode = true;
      toggleEditMode(true);
      const firstInput = document.getElementById('prof-name');
      if (firstInput) firstInput.focus();
    });
  }

  if (cancelBtn) {
    cancelBtn.addEventListener('click', () => {
      isEditMode = false;
      toggleEditMode(false);
      populateProfileData(currentStudent); // revert fields
      window.showToast("Cancelled", "Changes were discarded.", "info");
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener('click', async () => {
      try {
        const nameVal = document.getElementById('prof-name')?.value.trim();
        const idVal = document.getElementById('prof-id')?.value.trim();
        const emailVal = document.getElementById('prof-email')?.value.trim();
        const phoneVal = document.getElementById('prof-phone')?.value.trim();
        const dobVal = document.getElementById('prof-dob')?.value.trim();
        const genderVal = document.getElementById('prof-gender')?.value;

        const courseVal = document.getElementById('prof-course')?.value;
        const deptVal = document.getElementById('prof-dept')?.value.trim();
        const yearVal = document.getElementById('prof-year')?.value;
        const semVal = document.getElementById('prof-sem')?.value;
        
        const rawCgpa = document.getElementById('prof-cgpa')?.value.trim();
        const rawBacklogs = document.getElementById('prof-backlogs')?.value.trim();
        const rawTenth = document.getElementById('prof-10th')?.value.trim();
        const rawTwelfth = document.getElementById('prof-12th')?.value.trim();

        const cgpaVal = rawCgpa !== '' ? parseFloat(rawCgpa) : null;
        const backlogsVal = rawBacklogs !== '' ? parseInt(rawBacklogs, 10) : 0;
        const tenthVal = rawTenth !== '' ? parseFloat(rawTenth) : null;
        const twelfthVal = rawTwelfth !== '' ? parseFloat(rawTwelfth) : null;

        const updated = {
          name: nameVal || currentStudent.name || '',
          id: idVal || currentStudent.id || '',
          email: emailVal || currentStudent.email || '',
          phone: phoneVal || '',
          dob: dobVal || '',
          gender: genderVal || '',
          course: courseVal || '',
          department: deptVal || '',
          year: yearVal || '',
          semester: semVal || '',
          cgpa: isNaN(cgpaVal) ? null : cgpaVal,
          activeBacklogs: isNaN(backlogsVal) ? 0 : backlogsVal,
          tenthPercentage: isNaN(tenthVal) ? null : tenthVal,
          twelfthPercentage: isNaN(twelfthVal) ? null : twelfthVal,
          skills: currentStudent.skills || [],
          resume: currentStudent.resume || null,
          projects: currentStudent.projects || [],
          certifications: currentStudent.certifications || []
        };

        const saved = await window.StorageService.updateStudent(updated);
        currentStudent = saved;
        populateProfileData(saved);

        if (window.updateHeaderProfile) {
          window.updateHeaderProfile(saved);
        }

        toggleEditMode(false);
        isEditMode = false;
        window.showToast("Profile Updated", "Your profile details were saved successfully.", "success");
      } catch (err) {
        console.error("Failed to save profile:", err);
        window.showToast("Update Error", "Failed to update profile details.", "error");
      }
    });
  }
}

function toggleEditMode(enable) {
  const editableInputs = document.querySelectorAll('.profile-editable-field');
  const editBtn = document.getElementById('edit-profile-btn');
  const editActionsGroup = document.getElementById('edit-actions-group');

  editableInputs.forEach(input => {
    input.disabled = !enable;
  });

  if (enable) {
    if (editBtn) editBtn.classList.add('hidden');
    if (editActionsGroup) {
      editActionsGroup.classList.remove('hidden');
      editActionsGroup.style.display = 'flex';
    }
  } else {
    if (editBtn) editBtn.classList.remove('hidden');
    if (editActionsGroup) {
      editActionsGroup.classList.add('hidden');
      editActionsGroup.style.display = 'none';
    }
  }
}
