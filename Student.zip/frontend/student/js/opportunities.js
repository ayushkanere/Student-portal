/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * Placement Opportunities Page Controller
 */

let allDrives = [];
let appliedDriveIds = [];
let studentProfile = null;

document.addEventListener('DOMContentLoaded', async () => {
  await initOpportunitiesPage();
  setupFilterEventListeners();
});

async function initOpportunitiesPage() {
  try {
    studentProfile = await window.StorageService.getStudent();
    allDrives = await window.StorageService.getDrives();
    const apps = await window.StorageService.getApplications();
    appliedDriveIds = apps.map(a => a.driveId);

    const elOption = document.querySelector('#opp-eligibility-filter option[value="eligible"]');
    if (elOption && studentProfile) {
      elOption.textContent = studentProfile.cgpa ? `Eligible for Me (CGPA ≥ ${studentProfile.cgpa})` : 'Eligible for My CGPA';
    }

    renderOpportunities(allDrives);
    populateCompanyFilterOptions(allDrives);
  } catch (err) {
    console.error("Failed to load opportunities:", err);
    window.showToast("Error", "Could not load placement drives.", "error");
  }
}

/* --------------------------------------------------------------------------
   FILTER & SEARCH LOGIC
   -------------------------------------------------------------------------- */
function setupFilterEventListeners() {
  const searchInput = document.getElementById('opp-search-input');
  const companySelect = document.getElementById('opp-company-filter');
  const roleSelect = document.getElementById('opp-role-filter');
  const eligibilitySelect = document.getElementById('opp-eligibility-filter');
  const sortSelect = document.getElementById('opp-sort-select');

  const applyFilters = () => {
    const query = (searchInput?.value || '').toLowerCase().trim();
    const selectedCompany = companySelect?.value || 'all';
    const selectedRole = roleSelect?.value || 'all';
    const eligibilityMode = eligibilitySelect?.value || 'all';
    const sortBy = sortSelect?.value || 'deadline';

    let filtered = allDrives.filter(drive => {
      // Search match
      const matchesSearch = !query || 
        drive.companyName.toLowerCase().includes(query) ||
        drive.role.toLowerCase().includes(query) ||
        drive.requiredSkills.some(s => s.toLowerCase().includes(query));

      // Company match
      const matchesCompany = selectedCompany === 'all' || drive.companyName === selectedCompany;

      // Role match
      const matchesRole = selectedRole === 'all' || drive.role.toLowerCase().includes(selectedRole.toLowerCase());

      // Eligibility match
      let matchesEligibility = true;
      if (eligibilityMode === 'eligible') {
        matchesEligibility = studentProfile.cgpa >= drive.minCgpa;
      }

      return matchesSearch && matchesCompany && matchesRole && matchesEligibility;
    });

    // Sorting
    if (sortBy === 'deadline') {
      filtered.sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
    } else if (sortBy === 'package-desc') {
      filtered.sort((a, b) => extractMaxLpa(b.package) - extractMaxLpa(a.package));
    } else if (sortBy === 'package-asc') {
      filtered.sort((a, b) => extractMaxLpa(a.package) - extractMaxLpa(b.package));
    }

    renderOpportunities(filtered);
  };

  if (searchInput) searchInput.addEventListener('input', applyFilters);
  if (companySelect) companySelect.addEventListener('change', applyFilters);
  if (roleSelect) roleSelect.addEventListener('change', applyFilters);
  if (eligibilitySelect) eligibilitySelect.addEventListener('change', applyFilters);
  if (sortSelect) sortSelect.addEventListener('change', applyFilters);
}

function extractMaxLpa(pkgString) {
  const matches = pkgString.match(/(\d+(\.\d+)?)/g);
  if (!matches) return 0;
  return Math.max(...matches.map(Number));
}

function populateCompanyFilterOptions(drives) {
  const companySelect = document.getElementById('opp-company-filter');
  if (!companySelect) return;

  const companies = [...new Set(drives.map(d => d.companyName))];
  companies.forEach(comp => {
    const opt = document.createElement('option');
    opt.value = comp;
    opt.textContent = comp;
    companySelect.appendChild(opt);
  });
}

/* --------------------------------------------------------------------------
   RENDER OPPORTUNITIES
   -------------------------------------------------------------------------- */
function renderOpportunities(drives) {
  const grid = document.getElementById('opportunities-grid');
  const countBadge = document.getElementById('opp-results-count');
  if (!grid) return;

  if (countBadge) {
    countBadge.textContent = `${drives.length} drives available`;
  }

  if (drives.length === 0) {
    grid.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
        </div>
        <div class="empty-title">No matching drives found</div>
        <div class="empty-description">Try adjusting your search criteria or resetting filters to explore all available drives.</div>
      </div>
    `;
    return;
  }

  grid.innerHTML = drives.map(drive => {
    const isApplied = appliedDriveIds.includes(drive.id);
    const isEligible = studentProfile ? (studentProfile.cgpa >= drive.minCgpa) : true;

    return `
      <div class="opportunity-card">
        <div class="opp-header">
          <div style="display: flex; gap: 0.85rem; align-items: center;">
            <div class="company-logo-badge">${window.escapeHtml(drive.companyLogoText)}</div>
            <div>
              <div class="opp-company">${window.escapeHtml(drive.companyName)}</div>
              <h3 class="opp-role-title">${window.escapeHtml(drive.role)}</h3>
            </div>
          </div>
          <div>
            ${isEligible 
              ? `<span class="badge badge-success" style="font-size: 0.7rem;">Eligible</span>` 
              : `<span class="badge badge-warning" style="font-size: 0.7rem;">CGPA &lt; ${drive.minCgpa}</span>`
            }
          </div>
        </div>

        <div class="opp-meta-grid">
          <div class="opp-meta-item">
            <span class="opp-meta-label">Package (CTC)</span>
            <span class="opp-meta-value" style="color: var(--success-600);">${window.escapeHtml(drive.package)}</span>
          </div>
          <div class="opp-meta-item">
            <span class="opp-meta-label">Location</span>
            <span class="opp-meta-value">${window.escapeHtml(drive.location)}</span>
          </div>
          <div class="opp-meta-item">
            <span class="opp-meta-label">Drive Date</span>
            <span class="opp-meta-value">${formatDate(drive.driveDate)}</span>
          </div>
          <div class="opp-meta-item">
            <span class="opp-meta-label">Deadline</span>
            <span class="opp-meta-value" style="color: var(--danger-600);">${formatDate(drive.deadline)}</span>
          </div>
        </div>

        <div>
          <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 600; margin-bottom: 0.35rem;">REQUIRED SKILLS:</div>
          <div class="skills-pill-row">
            ${drive.requiredSkills.slice(0, 4).map(skill => `
              <span class="skill-pill">${window.escapeHtml(skill)}</span>
            `).join('')}
            ${drive.requiredSkills.length > 4 ? `<span class="skill-pill">+${drive.requiredSkills.length - 4} more</span>` : ''}
          </div>
        </div>

        <p style="font-size: 0.825rem; color: var(--text-muted); line-height: 1.45; margin: 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
          ${window.escapeHtml(drive.description)}
        </p>

        <div class="opp-footer">
          <button class="btn btn-secondary btn-sm" onclick="openDriveDetailsModal('${drive.id}')">
            View Details
          </button>
          ${isApplied 
            ? `<button class="btn btn-success btn-sm" disabled>Applied</button>`
            : `<button class="btn btn-primary btn-sm" onclick="handleApplyDrive('${drive.id}')">Apply Now</button>`
          }
        </div>
      </div>
    `;
  }).join('');
}

/* --------------------------------------------------------------------------
   VIEW DETAILS MODAL
   -------------------------------------------------------------------------- */
async function openDriveDetailsModal(driveId) {
  const drive = allDrives.find(d => d.id === driveId);
  if (!drive) return;

  const isApplied = appliedDriveIds.includes(drive.id);
  const isEligible = studentProfile.cgpa >= drive.minCgpa;

  let modal = document.getElementById('drive-details-modal');
  if (!modal) {
    const modalHtml = `
      <div id="drive-details-modal" class="modal-overlay">
        <div class="modal-container modal-lg">
          <div class="modal-header">
            <div style="display: flex; align-items: center; gap: 0.75rem;">
              <div class="company-logo-badge" id="modal-drive-logo">G</div>
              <div>
                <h3 class="modal-title" id="modal-drive-role">Role Title</h3>
                <div style="font-size: 0.85rem; color: var(--text-muted);" id="modal-drive-company">Company Name</div>
              </div>
            </div>
            <button class="modal-close-btn" onclick="closeDriveDetailsModal()">&times;</button>
          </div>
          <div class="modal-body" id="modal-drive-body">
            <!-- Dynamic Content -->
          </div>
          <div class="modal-footer" id="modal-drive-footer">
            <!-- Footer Action Button -->
          </div>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    modal = document.getElementById('drive-details-modal');
  }

  document.getElementById('modal-drive-logo').textContent = drive.companyLogoText;
  document.getElementById('modal-drive-role').textContent = drive.role;
  document.getElementById('modal-drive-company').textContent = `${drive.companyName} • ${drive.location}`;

  const bodyEl = document.getElementById('modal-drive-body');
  bodyEl.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: 1.25rem;">
      <div class="opp-meta-grid">
        <div class="opp-meta-item">
          <span class="opp-meta-label">Package (CTC)</span>
          <span class="opp-meta-value" style="color: var(--success-600);">${window.escapeHtml(drive.package)}</span>
        </div>
        <div class="opp-meta-item">
          <span class="opp-meta-label">Eligibility CGPA</span>
          <span class="opp-meta-value">Min ${drive.minCgpa} (Your CGPA: ${studentProfile.cgpa})</span>
        </div>
        <div class="opp-meta-item">
          <span class="opp-meta-label">Campus Drive Date</span>
          <span class="opp-meta-value">${formatDate(drive.driveDate)}</span>
        </div>
        <div class="opp-meta-item">
          <span class="opp-meta-label">Application Deadline</span>
          <span class="opp-meta-value" style="color: var(--danger-600);">${formatDate(drive.deadline)}</span>
        </div>
      </div>

      <div>
        <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 0.4rem; color: var(--text-primary);">Role Description</h4>
        <p style="font-size: 0.875rem; color: var(--text-secondary); line-height: 1.6;">${window.escapeHtml(drive.description)}</p>
      </div>

      <div>
        <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 0.5rem; color: var(--text-primary);">Selection Process & Rounds</h4>
        <ol style="padding-left: 1.25rem; font-size: 0.875rem; color: var(--text-secondary); line-height: 1.7; list-style: decimal;">
          ${drive.rounds.map(r => `<li>${window.escapeHtml(r)}</li>`).join('')}
        </ol>
      </div>

      <div>
        <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 0.5rem; color: var(--text-primary);">Eligible Departments</h4>
        <div class="skills-pill-row">
          ${drive.eligibilityDept.map(dept => `<span class="badge badge-primary">${window.escapeHtml(dept)}</span>`).join('')}
        </div>
      </div>

      <div>
        <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 0.5rem; color: var(--text-primary);">Required Technical Skills</h4>
        <div class="skills-pill-row">
          ${drive.requiredSkills.map(s => `<span class="skill-pill">${window.escapeHtml(s)}</span>`).join('')}
        </div>
      </div>
    </div>
  `;

  const footerEl = document.getElementById('modal-drive-footer');
  footerEl.innerHTML = `
    <button class="btn btn-secondary" onclick="closeDriveDetailsModal()">Close</button>
    ${isApplied 
      ? `<button class="btn btn-success" disabled>Already Applied</button>` 
      : `<button class="btn btn-primary" onclick="handleApplyDrive('${drive.id}'); closeDriveDetailsModal();">Apply for Opportunity</button>`
    }
  `;

  modal.classList.add('active');
}

function closeDriveDetailsModal() {
  const modal = document.getElementById('drive-details-modal');
  if (modal) modal.classList.remove('active');
}
window.openDriveDetailsModal = openDriveDetailsModal;
window.closeDriveDetailsModal = closeDriveDetailsModal;

/* --------------------------------------------------------------------------
   APPLY ACTION
   -------------------------------------------------------------------------- */
async function handleApplyDrive(driveId) {
  try {
    const app = await window.StorageService.applyToDrive(driveId);
    window.showToast("Application Submitted!", `You have applied to ${app.companyName}. Good luck!`, "success");
    
    // Refresh drive state
    appliedDriveIds.push(driveId);
    renderOpportunities(allDrives);
    window.syncNotificationBadges();
  } catch (err) {
    window.showToast("Application Notice", err.message, "warning");
  }
}
window.handleApplyDrive = handleApplyDrive;

function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch (e) {
    return dateStr;
  }
}
