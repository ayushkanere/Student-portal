/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * Authentication & Session Management Module
 * 
 * Provides mock authentication with session tokens in localStorage/sessionStorage.
 * Structured so real backend JWT / OAuth / SSO can replace the demo implementation.
 */

const AUTH_KEY = 'student_portal_session';

const AuthService = {
  // Check if session exists
  isAuthenticated() {
    return !!(localStorage.getItem(AUTH_KEY) || sessionStorage.getItem(AUTH_KEY));
  },

  // Get current active session
  getSession() {
    const data = localStorage.getItem(AUTH_KEY) || sessionStorage.getItem(AUTH_KEY);
    return data ? JSON.parse(data) : null;
  },

  // Perform login with validation
  async login(identifier, password, rememberMe = true) {
    // Simulate brief network latency
    await new Promise(resolve => setTimeout(resolve, 400));

    identifier = (identifier || '').trim();
    password = (password || '').trim();

    if (!identifier) {
      throw new Error("Please enter your Student ID or College Email.");
    }
    if (!password) {
      throw new Error("Please enter your password.");
    }

    // Strict validation: Must be a valid email format
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (!emailRegex.test(identifier)) {
      throw new Error("Please enter a valid email address (e.g. student@college.edu or name@domain.com).");
    }

    if (password.length < 4) {
      throw new Error("Password must be at least 4 characters.");
    }

    const cleanEmail = identifier.toLowerCase();
    const profileStorageKey = 'student_profile_' + cleanEmail;
    let student = null;
    let backendToken = null;

    // 1. Check if Node/MongoDB Backend API is running on localhost:5000
    try {
      const response = await fetch('http://localhost:5000/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: cleanEmail, password: password })
      });
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.student) {
          backendToken = data.token;
          const s = data.student;
          student = {
            id: s.studentId || '',
            name: s.fullName || '',
            email: s.collegeEmail || cleanEmail,
            phone: s.phoneNumber || '',
            dob: s.dateOfBirth || '',
            gender: s.gender || '',
            department: s.department || '',
            course: s.courseDegree || '',
            year: s.semesterYear || '',
            semester: s.semesterYear || '',
            cgpa: s.cgpa !== undefined ? s.cgpa : null,
            tenthPercentage: s.tenthPercentage !== undefined ? s.tenthPercentage : null,
            twelfthPercentage: s.twelfthPercentage !== undefined ? s.twelfthPercentage : null,
            activeBacklogs: s.activeBacklogs || 0,
            skills: s.skills || [],
            softSkills: s.softSkills || [],
            resume: s.resumeUrl ? { fileName: s.resumeUrl.split('/').pop(), uploadDate: new Date().toISOString().split('T')[0] } : null,
            certifications: s.certifications || [],
            projects: s.projects || [],
            preferredRoles: s.preferredRoles || [],
            profileCompletion: s.profileStrength || 0
          };
        }
      }
    } catch (apiErr) {
      // Backend is offline or not reachable; proceed seamlessly with browser persistence
    }

    // 2. Check local persistence keyed by email
    let localSaved = null;
    let activeSaved = null;

    const existingProfileStr = localStorage.getItem(profileStorageKey);
    if (existingProfileStr) {
      try {
        localSaved = JSON.parse(existingProfileStr);
      } catch (e) {}
    }

    const activeData = localStorage.getItem('placement_student_profile');
    if (activeData) {
      try {
        const parsed = JSON.parse(activeData);
        // If active profile matches this email or has no email yet, include it
        if (parsed && (!parsed.email || parsed.email.toLowerCase() === cleanEmail)) {
          activeSaved = parsed;
        }
      } catch (e) {}
    }

    // If student was not retrieved from backend API, merge local storage sources
    if (!student) {
      if (localSaved && activeSaved) {
        // Merge them, preserving non-empty values from whichever has data
        student = { ...localSaved };
        for (const [k, v] of Object.entries(activeSaved)) {
          if (v !== null && v !== "" && !(Array.isArray(v) && v.length === 0)) {
            if (student[k] === null || student[k] === "" || (Array.isArray(student[k]) && student[k].length === 0)) {
              student[k] = v;
            }
          }
        }
      } else {
        student = localSaved || activeSaved;
      }
    }

    // 3. If this student has truly NEVER logged in before, create a new profile template
    if (!student) {
      const localPart = cleanEmail.split('@')[0];
      const derivedName = localPart
        .replace(/[._-]+/g, ' ')
        .replace(/\b\w/g, c => c.toUpperCase())
        .trim();

      student = {
        id: "",
        name: derivedName,
        email: cleanEmail,
        phone: "",
        dob: "",
        gender: "",
        department: "",
        course: "",
        year: "",
        semester: "",
        cgpa: null,
        tenthPercentage: null,
        twelfthPercentage: null,
        activeBacklogs: 0,
        skills: [],
        softSkills: [],
        resume: null,
        certifications: [],
        projects: [],
        preferredRoles: [],
        profileCompletion: 0
      };
    }

    // Guarantee that email is strictly the logged-in email
    student.email = cleanEmail;

    // Persist immediately to email-keyed store
    localStorage.setItem(profileStorageKey, JSON.stringify(student));
    if (student.id) {
      localStorage.setItem('student_profile_' + student.id.toUpperCase(), JSON.stringify(student));
    }

    // Set active student in StorageService (syncs active profile & completion)
    if (window.StorageService) {
      await window.StorageService.setStudent(student);
    } else {
      localStorage.setItem('placement_student_profile', JSON.stringify(student));
    }

    const sessionPayload = {
      token: backendToken || ("demo-jwt-" + Date.now() + "-" + Math.random().toString(36).substring(2, 9)),
      studentId: student.id || "",
      name: student.name || cleanEmail.split('@')[0],
      email: cleanEmail,
      department: student.department || "",
      course: student.course || "",
      profileKey: profileStorageKey,
      loginTime: new Date().toISOString()
    };

    if (rememberMe) {
      localStorage.setItem(AUTH_KEY, JSON.stringify(sessionPayload));
    } else {
      sessionStorage.setItem(AUTH_KEY, JSON.stringify(sessionPayload));
    }

    return sessionPayload;
  },

  // Perform logout
  logout() {
    // Note: Do NOT clear student_profile_<email> or placement_student_profile on logout!
    // The student's filled data must be preserved so when they log back in, all their data is still there.
    localStorage.removeItem(AUTH_KEY);
    sessionStorage.removeItem(AUTH_KEY);
    // Find path back to login page
    const isInPagesDir = window.location.pathname.includes('/pages/');
    window.location.href = isInPagesDir ? '../index.html' : 'index.html';
  },

  // Route protection guard
  requireAuth() {
    const isLoginPage = window.location.pathname.endsWith('index.html') && !window.location.pathname.includes('/pages/');
    const authed = this.isAuthenticated();

    if (!authed && !isLoginPage) {
      // Redirect to login
      const isInPagesDir = window.location.pathname.includes('/pages/');
      window.location.href = isInPagesDir ? '../index.html' : 'index.html';
    } else if (authed && isLoginPage) {
      // Already logged in, go straight to dashboard
      window.location.href = 'pages/dashboard.html';
    }
  }
};

window.AuthService = AuthService;
