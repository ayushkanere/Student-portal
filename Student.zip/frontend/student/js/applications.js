/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * My Applications Page Controller
 */

let myApplications = [];

document.addEventListener('DOMContentLoaded', async () => {
  await initApplicationsPage();
  setupApplicationsFilter();
});

async function initApplicationsPage() {
  try {
    myApplications = await window.StorageService.getApplications();
    renderApplicationsList(myApplications);
    updateSummaryBadges(myApplications);
  } catch (err) {
    console.error("Failed to load applications:", err);
    window.showToast("Error", "Could not load applications.", "error");
  }
}

function updateSummaryBadges(apps) {
  const totalEl = document.getElementById('apps-count-total');
  const activeEl = document.getElementById('apps-count-active');
  const selectedEl = document.getElementById('apps-count-selected');

  if (totalEl) totalEl.textContent = apps.length;
  if (activeEl) {
    const activeCount = apps.filter(a => ['Applied', 'Under Review', 'Assessment', 'Interview', 'Shortlisted'].includes(a.status)).length;
    activeEl.textContent = activeCount;
  }
  if (selectedEl) {
    const selectedCount = apps.filter(a => a.status === 'Selected').length;
    selectedEl.textContent = selectedCount;
  }
}

function setupApplicationsFilter() {
  const searchInput = document.getElementById('app-search-input');
  const statusFilter = document.getElementById('app-status-filter');
  const sortSelect = document.getElementById('app-sort-select');

  const filterHandler = () => {
    const query = (searchInput?.value || '').toLowerCase().trim();
    const selectedStatus = statusFilter?.value || 'all';
    const sortBy = sortSelect?.value || 'date-desc';

    let filtered = myApplications.filter(app => {
      const matchesSearch = !query ||
        app.companyName.toLowerCase().includes(query) ||
        app.role.toLowerCase().includes(query);

      let matchesStatus = true;
      if (selectedStatus !== 'all') {
        matchesStatus = app.status.toLowerCase() === selectedStatus.toLowerCase();
      }

      return matchesSearch && matchesStatus;
    });

    if (sortBy === 'date-desc') {
      filtered.sort((a, b) => new Date(b.appliedDate) - new Date(a.appliedDate));
    } else if (sortBy === 'date-asc') {
      filtered.sort((a, b) => new Date(a.appliedDate) - new Date(b.appliedDate));
    } else if (sortBy === 'company') {
      filtered.sort((a, b) => a.companyName.localeCompare(b.companyName));
    }

    renderApplicationsList(filtered);
  };

  if (searchInput) searchInput.addEventListener('input', filterHandler);
  if (statusFilter) statusFilter.addEventListener('change', filterHandler);
  if (sortSelect) sortSelect.addEventListener('change', filterHandler);
}

function renderApplicationsList(apps) {
  const container = document.getElementById('applications-table-body');
  if (!container) return;

  if (apps.length === 0) {
    container.innerHTML = `
      <tr>
        <td colspan="6">
          <div class="empty-state">
            <div class="empty-icon">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
            </div>
            <div class="empty-title">No applications found</div>
            <div class="empty-description">You haven't submitted applications matching the selected criteria.</div>
            <a href="opportunities.html" class="btn btn-primary btn-sm">Explore Placement Drives</a>
          </div>
        </td>
      </tr>
    `;
    return;
  }

  container.innerHTML = apps.map(app => {
    return `
      <tr>
        <td>
          <div style="display: flex; align-items: center; gap: 0.75rem;">
            <div class="company-logo-badge" style="width: 38px; height: 38px; font-size: 0.95rem;">
              ${window.escapeHtml(app.companyLogoText || 'C')}
            </div>
            <div>
              <div style="font-weight: 700; color: var(--text-primary);">${window.escapeHtml(app.companyName)}</div>
              <div style="font-size: 0.75rem; color: var(--text-subtle);">${app.id}</div>
            </div>
          </div>
        </td>
        <td>
          <div style="font-weight: 600; color: var(--text-secondary);">${window.escapeHtml(app.role)}</div>
        </td>
        <td>
          <span style="font-size: 0.85rem; color: var(--text-muted);">${formatDate(app.appliedDate)}</span>
        </td>
        <td>
          <span class="badge badge-${app.status.toLowerCase().replace(/\s+/g, '-')}">
            ${window.escapeHtml(app.status)}
          </span>
        </td>
        <td>
          <div style="font-size: 0.825rem; color: var(--text-secondary); max-width: 280px; line-height: 1.4;">
            ${window.escapeHtml(app.nextStep || 'Application under consideration')}
            ${app.interviewDate ? `<div style="font-size: 0.75rem; color: var(--primary-600); font-weight: 600; margin-top: 2px;">📅 Interview: ${formatDate(app.interviewDate)}</div>` : ''}
          </div>
        </td>
        <td class="text-right">
          <button class="btn btn-secondary btn-sm" onclick="openApplicationModal('${app.id}')">
            View Details
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

/* --------------------------------------------------------------------------
   APPLICATION DETAILS MODAL
   -------------------------------------------------------------------------- */
function openApplicationModal(appId) {
  const app = myApplications.find(a => a.id === appId);
  if (!app) return;

  let modal = document.getElementById('application-details-modal');
  if (!modal) {
    const modalHtml = `
      <div id="application-details-modal" class="modal-overlay">
        <div class="modal-container modal-lg">
          <div class="modal-header">
            <div>
              <h3 class="modal-title" id="app-modal-title">Application Status</h3>
              <div style="font-size: 0.825rem; color: var(--text-muted);" id="app-modal-subtitle">ID</div>
            </div>
            <button class="modal-close-btn" onclick="closeApplicationModal()">&times;</button>
          </div>
          <div class="modal-body" id="app-modal-body">
            <!-- Dynamic Content -->
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeApplicationModal()">Close</button>
          </div>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    modal = document.getElementById('application-details-modal');
  }

  document.getElementById('app-modal-title').textContent = `${app.companyName} — ${app.role}`;
  document.getElementById('app-modal-subtitle').textContent = `Application Reference: ${app.id} • Applied on ${formatDate(app.appliedDate)}`;

  // Build timeline stepper
  const stages = [
    { name: "Applied", label: "Applied" },
    { name: "Under Review", label: "Review" },
    { name: "Assessment", label: "Assessment" },
    { name: "Interview", label: "Interview" },
    { name: "Selected", label: "Decision" }
  ];

  const currentStatus = app.status;
  const stageNames = ["Applied", "Under Review", "Assessment", "Interview", "Selected"];
  const currentIdx = stageNames.indexOf(currentStatus);

  const stepperHtml = `
    <div class="timeline-stepper">
      ${stages.map((s, idx) => {
        let stateClass = '';
        if (currentStatus === 'Rejected') {
          stateClass = (idx === 0) ? 'completed' : (idx === 1 ? 'active' : '');
        } else if (idx < currentIdx) {
          stateClass = 'completed';
        } else if (idx === currentIdx) {
          stateClass = 'active';
        }
        return `
          <div class="stepper-item ${stateClass}">
            <div class="stepper-dot">${idx + 1}</div>
            <div class="stepper-label">${s.label}</div>
          </div>
        `;
      }).join('')}
    </div>
  `;

  const historyHtml = (app.history || []).map(h => `
    <div style="display: flex; gap: 1rem; padding: 0.75rem 0; border-bottom: 1px solid var(--border-color);">
      <div style="width: 100px; font-size: 0.8rem; color: var(--text-subtle); flex-shrink: 0;">${h.date}</div>
      <div style="flex: 1;">
        <div style="font-weight: 600; font-size: 0.85rem; color: var(--text-primary);">${window.escapeHtml(h.stage)}</div>
        <div style="font-size: 0.825rem; color: var(--text-muted); margin-top: 2px;">${window.escapeHtml(h.notes)}</div>
      </div>
    </div>
  `).join('');

  document.getElementById('app-modal-body').innerHTML = `
    <div style="display: flex; flex-direction: column; gap: 1.5rem;">
      <div style="background-color: var(--bg-surface-secondary); padding: 1.25rem; border-radius: var(--radius-md);">
        <div style="font-size: 0.8rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Current Status</div>
        <div style="display: flex; align-items: center; gap: 0.75rem; margin-top: 0.35rem;">
          <span class="badge badge-${app.status.toLowerCase().replace(/\s+/g, '-')}" style="font-size: 0.85rem; padding: 0.35rem 0.85rem;">
            ${window.escapeHtml(app.status)}
          </span>
          <span style="font-weight: 600; color: var(--text-primary);">${window.escapeHtml(app.currentStage || app.status)}</span>
        </div>
        <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 0.5rem; line-height: 1.5;">
          <strong>Next Step:</strong> ${window.escapeHtml(app.nextStep || 'Stay tuned for updates from the Placement Cell.')}
        </div>
      </div>

      <div>
        <h4 style="font-size: 0.95rem; font-weight: 700; color: var(--text-primary); margin-bottom: 0.5rem;">Application Progress</h4>
        ${stepperHtml}
      </div>

      <div>
        <h4 style="font-size: 0.95rem; font-weight: 700; color: var(--text-primary); margin-bottom: 0.5rem;">Status History & Notes</h4>
        <div>${historyHtml}</div>
      </div>
    </div>
  `;

  modal.classList.add('active');
}

function closeApplicationModal() {
  const modal = document.getElementById('application-details-modal');
  if (modal) modal.classList.remove('active');
}
window.openApplicationModal = openApplicationModal;
window.closeApplicationModal = closeApplicationModal;

function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch (e) {
    return dateStr;
  }
}
