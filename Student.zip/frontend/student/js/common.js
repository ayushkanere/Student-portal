/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * Shared Layout, Header, Sidebar, Theme, Toast & Modal Manager
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Enforce session check if auth service is present
  if (window.AuthService) {
    window.AuthService.requireAuth();
  }

  // Initialize theme from settings
  await initTheme();

  // Setup layout components
  setupHeaderAndSidebar();

  // Setup toast container
  setupToastContainer();

  // Setup logout confirmation modal
  setupLogoutModal();

  // Sync notification badges
  syncNotificationBadges();
});

/* --------------------------------------------------------------------------
   THEME INITIALIZATION
   -------------------------------------------------------------------------- */
async function initTheme() {
  const settings = await window.StorageService.getSettings();
  const theme = settings?.theme || 'light';
  document.documentElement.setAttribute('data-theme', theme);
  const themeIcon = document.getElementById('theme-toggle-icon');
  if (themeIcon) {
    themeIcon.innerHTML = theme === 'dark' ? getSunIcon() : getMoonIcon();
  }
}

async function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'light';
  const newTheme = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', newTheme);
  
  await window.StorageService.updateSettings({ theme: newTheme });
  
  const themeIcon = document.getElementById('theme-toggle-icon');
  if (themeIcon) {
    themeIcon.innerHTML = newTheme === 'dark' ? getSunIcon() : getMoonIcon();
  }
  showToast("Theme Updated", `Switched to ${newTheme} mode.`, "info");
}

/* --------------------------------------------------------------------------
   HEADER & SIDEBAR SETUP
   -------------------------------------------------------------------------- */
async function setupHeaderAndSidebar() {
  // Highlight active link in sidebar
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href && currentPath.endsWith(href)) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // Populate student details in header if elements exist
  try {
    const student = await window.StorageService.getStudent();
    updateHeaderProfile(student);
  } catch (err) {
    console.warn("Could not load student for header:", err);
  }

  // Profile dropdown menu toggle
  const profileTrigger = document.getElementById('user-profile-trigger');
  const profileDropdown = document.getElementById('user-profile-dropdown');
  if (profileTrigger && profileDropdown) {
    profileTrigger.addEventListener('click', (e) => {
      e.stopPropagation();
      profileDropdown.classList.toggle('show');
    });

    document.addEventListener('click', (e) => {
      if (!profileTrigger.contains(e.target) && !profileDropdown.contains(e.target)) {
        profileDropdown.classList.remove('show');
      }
    });
  }

  // Mobile sidebar toggle
  const sidebarToggleBtn = document.getElementById('sidebar-toggle-btn');
  const sidebar = document.querySelector('.sidebar');
  let overlay = document.querySelector('.sidebar-overlay');
  
  if (!overlay && sidebar) {
    overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    document.body.appendChild(overlay);
  }

  if (sidebarToggleBtn && sidebar) {
    sidebarToggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      if (overlay) overlay.classList.toggle('active');
    });

    if (overlay) {
      overlay.addEventListener('click', () => {
        sidebar.classList.remove('open');
        overlay.classList.remove('active');
      });
    }
  }

  // Theme toggle button click
  const themeToggleBtn = document.getElementById('theme-toggle-btn');
  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', toggleTheme);
  }
}

function updateHeaderProfile(student) {
  if (!student) return;
  const headerUserName = document.getElementById('header-user-name');
  const headerUserDept = document.getElementById('header-user-dept');
  const headerUserAvatar = document.getElementById('header-user-avatar');

  const displayName = (student.name && student.name.trim()) ? student.name : (student.email ? student.email.split('@')[0] : (student.id || "Student"));
  if (headerUserName) headerUserName.textContent = displayName;
  
  if (headerUserDept) {
    if (student.course && student.cgpa) {
      headerUserDept.textContent = `${student.course} • ${student.cgpa} CGPA`;
    } else if (student.course) {
      headerUserDept.textContent = student.course;
    } else if (student.department) {
      headerUserDept.textContent = student.department;
    } else {
      headerUserDept.textContent = 'Profile Incomplete';
    }
  }
  
  if (headerUserAvatar) {
    if (student.name && student.name.trim()) {
      const initials = student.name.trim().split(/\s+/).map(n => n[0].toUpperCase()).join('').substring(0, 2);
      headerUserAvatar.textContent = initials || 'ST';
    } else if (student.email) {
      headerUserAvatar.textContent = student.email.substring(0, 2).toUpperCase();
    } else {
      headerUserAvatar.textContent = 'ST';
    }
  }
}
window.updateHeaderProfile = updateHeaderProfile;

/* --------------------------------------------------------------------------
   NOTIFICATION BADGE SYNCHRONIZATION
   -------------------------------------------------------------------------- */
async function syncNotificationBadges() {
  const unreadCount = await window.StorageService.getUnreadCount();
  const headerBadge = document.getElementById('header-notif-dot');
  const sidebarBadge = document.getElementById('sidebar-notif-badge');

  if (headerBadge) {
    if (unreadCount > 0) {
      headerBadge.classList.remove('hidden');
    } else {
      headerBadge.classList.add('hidden');
    }
  }

  if (sidebarBadge) {
    if (unreadCount > 0) {
      sidebarBadge.textContent = unreadCount;
      sidebarBadge.classList.remove('hidden');
    } else {
      sidebarBadge.classList.add('hidden');
    }
  }
}
window.syncNotificationBadges = syncNotificationBadges;

/* --------------------------------------------------------------------------
   LOGOUT MODAL
   -------------------------------------------------------------------------- */
function setupLogoutModal() {
  // Inject modal markup if not already present
  if (!document.getElementById('logout-modal')) {
    const modalHtml = `
      <div id="logout-modal" class="modal-overlay">
        <div class="modal-container" style="max-width: 420px;">
          <div class="modal-header">
            <h3 class="modal-title">Confirm Logout</h3>
            <button class="modal-close-btn" id="logout-modal-close">&times;</button>
          </div>
          <div class="modal-body">
            <p style="color: var(--text-secondary); font-size: 0.95rem;">Are you sure you want to log out of the Placement Portal?</p>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="logout-modal-cancel">Cancel</button>
            <button class="btn btn-danger" id="logout-modal-confirm">Log Out</button>
          </div>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHtml);
  }

  const modal = document.getElementById('logout-modal');
  const closeBtn = document.getElementById('logout-modal-close');
  const cancelBtn = document.getElementById('logout-modal-cancel');
  const confirmBtn = document.getElementById('logout-modal-confirm');

  const close = () => modal.classList.remove('active');

  if (closeBtn) closeBtn.addEventListener('click', close);
  if (cancelBtn) cancelBtn.addEventListener('click', close);
  if (confirmBtn) {
    confirmBtn.addEventListener('click', () => {
      window.AuthService.logout();
    });
  }

  // Bind to all logout trigger elements
  document.querySelectorAll('.logout-trigger').forEach(trigger => {
    trigger.addEventListener('click', (e) => {
      e.preventDefault();
      modal.classList.add('active');
    });
  });
}

/* --------------------------------------------------------------------------
   TOAST NOTIFICATION SYSTEM
   -------------------------------------------------------------------------- */
function setupToastContainer() {
  if (!document.getElementById('toast-container')) {
    const container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
}

function showToast(title, message, type = 'info', duration = 4000) {
  const container = document.getElementById('toast-container') || document.body;
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  const iconSvg = type === 'success' ? getCheckCircleIcon() :
                  type === 'error' ? getAlertCircleIcon() :
                  type === 'warning' ? getAlertTriangleIcon() : getInfoIcon();

  toast.innerHTML = `
    <div class="toast-icon">${iconSvg}</div>
    <div class="toast-content">
      <div class="toast-title">${escapeHtml(title)}</div>
      <div class="toast-msg">${escapeHtml(message)}</div>
    </div>
    <button class="toast-close">&times;</button>
  `;

  container.appendChild(toast);

  const removeToast = () => {
    toast.classList.add('hiding');
    setTimeout(() => toast.remove(), 250);
  };

  toast.querySelector('.toast-close').addEventListener('click', removeToast);
  setTimeout(removeToast, duration);
}
window.showToast = showToast;

/* --------------------------------------------------------------------------
   UTILITY ICONS (Inline SVG to avoid external font/network issues)
   -------------------------------------------------------------------------- */
function getSunIcon() {
  return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>`;
}

function getMoonIcon() {
  return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>`;
}

function getCheckCircleIcon() {
  return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`;
}

function getAlertCircleIcon() {
  return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`;
}

function getAlertTriangleIcon() {
  return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`;
}

function getInfoIcon() {
  return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`;
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
window.escapeHtml = escapeHtml;
