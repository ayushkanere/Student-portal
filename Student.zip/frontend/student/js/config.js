﻿/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * API Configuration Module
 * 
 * Central place to configure backend server endpoints.
 */

const CONFIG = {
  // Base URL of the running Node.js / Express backend server
  API_BASE_URL: 'http://localhost:5000',

  // LocalStorage key where the backend JWT token is stored
  AUTH_TOKEN_KEY: 'authToken'
};

// Expose globally to browser window
window.CONFIG = CONFIG;
