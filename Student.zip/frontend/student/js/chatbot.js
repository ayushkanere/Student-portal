/**
 * PLACEMENT CELL CHATBOT — STUDENT PORTAL
 * AI Placement Assistant Service & UI Controller
 * 
 * Cleanly decoupled so that local pattern-matching can easily be swapped
 * for a remote LLM endpoint (e.g. POST /api/chatbot/query).
 */

const ChatbotService = {
  /**
   * Future Integration Hook:
   * Replace this local mock engine with:
   * const res = await fetch('/api/chatbot/query', { method: 'POST', body: JSON.stringify({ message: query, studentId: student.id }) });
   * return await res.json();
   */
  async sendMessage(userMessage) {
    // Simulate real AI network and inference latency
    await new Promise(resolve => setTimeout(resolve, 600));

    const student = await window.StorageService.getStudent();
    const drives = await window.StorageService.getDrives();
    const applications = await window.StorageService.getApplications();
    const query = userMessage.toLowerCase().trim();

    const studentName = student?.name || 'Student';
    const userCgpa = (student?.cgpa !== null && student?.cgpa !== undefined && student?.cgpa !== '') ? parseFloat(student.cgpa) : null;
    const backlogs = student?.activeBacklogs !== undefined && student?.activeBacklogs !== null ? parseInt(student.activeBacklogs, 10) : 0;
    const program = (student?.course || student?.department) ? `${student.course || ''}${student.course && student.department ? ' - ' : ''}${student.department || ''}` : 'Your Program';

    // 1. Dynamic query: Eligibility check ("Which companies am I eligible for?", "am I eligible", etc.)
    if (
      query.includes("eligible") ||
      query.includes("eligibility") ||
      query.includes("which company") ||
      query.includes("companies can i apply") ||
      query.includes("can i apply") ||
      query.includes("qualify") ||
      query.includes("where can i apply")
    ) {
      if (userCgpa === null || isNaN(userCgpa)) {
        let msg = `Hello **${studentName}**, your academic details (CGPA) have not been added to your profile yet! ⚠️\n\n`;
        msg += `Please head over to **My Profile** and enter your CGPA so I can accurately calculate which placement drives you qualify for.\n\n`;
        msg += `**Minimum CGPA Criteria for Active Drives:**\n`;
        drives.forEach(d => {
          msg += `• **${d.companyName}** (${d.role}) — Min CGPA: **${d.minCgpa}** | Package: ${d.package}\n`;
        });
        msg += `\nOnce you update your CGPA, ask me again!`;
        return msg;
      }

      const eligibleDrives = drives.filter(d => userCgpa >= d.minCgpa && backlogs === 0);
      const ineligibleDrives = drives.filter(d => userCgpa < d.minCgpa || backlogs > 0);
      const percent = Math.round((eligibleDrives.length / drives.length) * 100);

      let resp = `Based on your verified profile (**${program}**, CGPA: **${userCgpa} / 10**, Active Backlogs: **${backlogs}**), you are eligible for **${percent}% (${eligibleDrives.length}/${drives.length})** of currently active placement drives! 🎉\n\n`;

      if (eligibleDrives.length > 0) {
        resp += `**Companies You Are Eligible For:**\n`;
        eligibleDrives.forEach(d => {
          resp += `• **${d.companyName}** — ${d.role} (Min CGPA: ${d.minCgpa} | Package: ${d.package})\n`;
        });
      } else {
        resp += `Currently no active drives match a CGPA of ${userCgpa} with ${backlogs} active backlog(s).\n`;
      }

      if (ineligibleDrives.length > 0) {
        resp += `\n**Requires Higher Criteria:**\n`;
        ineligibleDrives.forEach(d => {
          resp += `• **${d.companyName}** — Requires ${d.minCgpa} CGPA (Your CGPA: ${userCgpa})\n`;
        });
      }

      resp += `\nYou can head over to the **Placement Opportunities** page to apply directly!`;
      return resp;
    }

    // 2. Dynamic query: Student Profile & Credentials Snapshot
    if (
      query.includes("my profile") ||
      query.includes("my details") ||
      query.includes("my cgpa") ||
      query.includes("my marks") ||
      query.includes("my resume") ||
      query.includes("who am i") ||
      query.includes("my info")
    ) {
      const studentId = student?.id || 'Not added yet';
      const email = student?.email || 'Not added yet';
      const phone = student?.phone || 'Not added yet';
      const course = student?.course || 'Not added yet';
      const dept = student?.department || 'Not added yet';
      const yearSem = (student?.year || student?.semester) ? `${student.year || ''} (${student.semester || ''})`.trim() : 'Not added yet';
      const cgpaDisplay = userCgpa !== null ? `${userCgpa} / 10` : 'Not added yet';
      const skills = (student?.skills && student.skills.length) ? student.skills.join(', ') : 'None added yet';
      const resumeStatus = (student?.resume && student?.resume?.fileName) ? `Verified (${student.resume.fileName})` : 'Not uploaded yet';
      const completion = student?.profileCompletion !== undefined ? student.profileCompletion : 0;

      return `**Your Active Profile Snapshot:**\n• **Full Name:** ${studentName}\n• **Student ID:** ${studentId}\n• **College Email:** ${email}\n• **Phone:** ${phone}\n• **Course & Dept:** ${course} — ${dept}\n• **Year & Semester:** ${yearSem}\n• **Current CGPA:** **${cgpaDisplay}**\n• **Active Backlogs:** ${backlogs}\n• **Skills:** ${skills}\n• **Placement Resume:** ${resumeStatus}\n• **Profile Strength:** **${completion}%**\n\nYou can update any details under **My Profile** at any time!`;
    }

    // 3. Dynamic query: Applications Status Tracking
    if (query.includes("application") || query.includes("status") || query.includes("applied") || query.includes("track")) {
      if (!applications || applications.length === 0) {
        return "You have not submitted any placement applications yet. Visit the **Placement Opportunities** page to browse active campus drives and apply!";
      }
      let resp = `You have **${applications.length} submitted application(s)** on file:\n\n`;
      applications.forEach(a => {
        resp += `• **${a.companyName}** (${a.role})\n  - **Status:** **${a.status}**\n  - **Applied Date:** ${a.appliedDate || 'Recent'}\n  - **Next Step:** ${a.nextStep || 'Review in progress'}\n\n`;
      });
      resp += `You can view the full 5-stage selection timeline under **My Applications**!`;
      return resp;
    }

    // 4. Dynamic query: Specific Company Check (e.g. Google, Microsoft, Cisco, TCS, Amazon, Deloitte)
    for (const drive of drives) {
      if (query.includes(drive.companyName.toLowerCase()) || query.includes(drive.companyLogoText.toLowerCase())) {
        const isEligible = userCgpa !== null ? userCgpa >= drive.minCgpa : false;
        const statusText = userCgpa !== null 
          ? (isEligible ? `✅ You are eligible! (Your CGPA: ${userCgpa} ≥ ${drive.minCgpa})` : `⚠️ Requires ${drive.minCgpa} CGPA (Your CGPA: ${userCgpa})`)
          : `ℹ️ Requires ${drive.minCgpa} CGPA (Add your CGPA in My Profile to check)`;

        return `**${drive.companyName} Drive Information:**\n• **Role:** ${drive.role}\n• **Package:** ${drive.package}\n• **Min CGPA Required:** ${drive.minCgpa}\n• **Your Status:** ${statusText}\n• **Eligible Programs:** ${(drive.eligibilityDept || []).join(', ')}\n• **Selection Rounds:**\n${drive.rounds.map((r, i) => `  ${i + 1}. ${r}`).join('\n')}\n• **Application Deadline:** ${drive.deadline}\n\nWould you like to apply on the **Placement Opportunities** page?`;
      }
    }

    // 5. Static Knowledge Base check
    const kb = window.SEED_DATA.aiKnowledgeBase || [];
    for (const entry of kb) {
      if (entry.keywords.some(k => query.includes(k.toLowerCase()))) {
        return entry.response;
      }
    }

    // 6. Intelligent Fallback with Real Student Context
    const cgpaPill = userCgpa !== null ? `your **${userCgpa} CGPA**` : 'your academic profile';
    return `Hello **${studentName}**! I am your **Placement AI Assistant**.\n\nI can help you with:\n• Checking which placement drives match ${cgpaPill}\n• Deadlines and selection rounds for companies like Google, Microsoft, Cisco, and TCS\n• Tracking your application & interview statuses\n• Placement preparation tips, coding interview rounds, and required documentation.\n\nTry clicking one of the suggested prompts below or ask me a specific question!`;
  }
};

/* --------------------------------------------------------------------------
   UI CONTROLLER
   -------------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', () => {
  setupChatbotUI();
});

function setupChatbotUI() {
  const form = document.getElementById('chat-input-form');
  const input = document.getElementById('chat-user-input');
  const clearBtn = document.getElementById('chat-clear-btn');
  const suggestionsContainer = document.getElementById('chat-suggestions');

  // Load existing history or show welcome message
  loadChatHistory();

  // Send message on submit
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const text = input.value.trim();
      if (!text) return;

      input.value = '';
      await handleUserMessage(text);
    });
  }

  // Clear chat
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      window.StorageService.clearChatHistory();
      const thread = document.getElementById('chat-messages-thread');
      if (thread) thread.innerHTML = '';
      renderWelcomeBotMessage();
      window.showToast("Chat Cleared", "Conversation history was reset.", "info");
    });
  }

  // Suggested chips click
  if (suggestionsContainer) {
    suggestionsContainer.addEventListener('click', async (e) => {
      const chip = e.target.closest('.suggestion-chip');
      if (chip) {
        const text = chip.getAttribute('data-question') || chip.textContent.trim();
        await handleUserMessage(text);
      }
    });
  }
}

async function handleUserMessage(text) {
  appendMessage('user', text);
  saveCurrentChatHistory();

  showTypingIndicator();

  try {
    const reply = await ChatbotService.sendMessage(text);
    hideTypingIndicator();
    appendMessage('bot', reply);
    saveCurrentChatHistory();
  } catch (err) {
    hideTypingIndicator();
    appendMessage('bot', "I'm having trouble connecting to the placement intelligence service. Please try again in a moment.");
  }
}

function appendMessage(sender, text) {
  const thread = document.getElementById('chat-messages-thread');
  if (!thread) return;

  const bubble = document.createElement('div');
  bubble.className = `message-bubble ${sender}`;

  const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const avatarText = sender === 'user' ? 'ME' : 'AI';

  bubble.innerHTML = `
    <div class="message-avatar">${avatarText}</div>
    <div class="message-content-box">
      <div class="message-body">${formatMessageText(text)}</div>
      <div class="message-time">${timeStr}</div>
    </div>
  `;

  thread.appendChild(bubble);
  thread.scrollTop = thread.scrollHeight;
}

function showTypingIndicator() {
  const thread = document.getElementById('chat-messages-thread');
  if (!thread || document.getElementById('typing-indicator-bubble')) return;

  const typingEl = document.createElement('div');
  typingEl.id = 'typing-indicator-bubble';
  typingEl.className = 'message-bubble bot';
  typingEl.innerHTML = `
    <div class="message-avatar">AI</div>
    <div class="typing-bubble">
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
    </div>
  `;
  thread.appendChild(typingEl);
  thread.scrollTop = thread.scrollHeight;
}

function hideTypingIndicator() {
  const el = document.getElementById('typing-indicator-bubble');
  if (el) el.remove();
}

function formatMessageText(text) {
  if (!text) return '';
  // Convert markdown bold **text** to <strong>
  let html = window.escapeHtml(text);
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  // Convert newlines to <br>
  html = html.replace(/\n/g, '<br>');
  return html;
}

async function renderWelcomeBotMessage() {
  const student = await window.StorageService.getStudent();
  const name = (student && student.name) ? ` **${student.name}**` : '';
  appendMessage('bot', `👋 Welcome${name} to the **Placement Cell AI Assistant**! How can I assist your placement journey today? Ask me about your company eligibility, active drives, application statuses, or interview preparation tips.`);
}

function saveCurrentChatHistory() {
  const thread = document.getElementById('chat-messages-thread');
  if (thread) {
    window.StorageService.saveChatHistory(thread.innerHTML);
  }
}

function loadChatHistory() {
  const saved = window.StorageService.getChatHistory();
  const thread = document.getElementById('chat-messages-thread');
  if (thread) {
    if (saved) {
      thread.innerHTML = saved;
      thread.scrollTop = thread.scrollHeight;
    } else {
      renderWelcomeBotMessage();
    }
  }
}

window.ChatbotService = ChatbotService;
